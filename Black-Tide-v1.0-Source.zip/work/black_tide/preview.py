import numpy as np,json,pathlib
from PIL import Image,ImageDraw,ImageFont
W=pathlib.Path('work/black_tide');D=pathlib.Path('outputs/黑潮_夺宝战争');name='Black_Tide_6P'
a=np.load(W/'terrain.npz');sc=json.loads((W/'scene.json').read_text());h=a['height'][30:630,30:630]
gy,gx=np.gradient(h);shade=np.clip((-.6*gx+.5*gy+4)/np.sqrt(gx*gx+gy*gy+16),.3,1.3)
z=np.clip((h-110)/90,0,1)[...,None];rgb=np.array([9,38,58])*(1-z)+np.array([37,115,121])*z
land=h>200;t=np.clip((h-200)/27,0,1)[...,None];lc=np.array([213,193,143])*(1-t)+np.array([77,116,77])*t
rgb[land]=lc[land]*(.6+.4*shade[land,None])
for key,col in [('roadmask',[150,134,104]),('urbanmask',[137,148,141]),('portmask',[149,157,147])]:rgb[a[key][30:630,30:630]]=col
im=Image.fromarray(np.clip(rgb,0,255).astype('uint8')[::-1]).resize((1100,1100),Image.Resampling.LANCZOS).convert('RGB');draw=ImageDraw.Draw(im)
font=next(p for p in ['/System/Library/Fonts/Supplemental/Arial.ttf','C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'] if pathlib.Path(p).exists())
f=lambda n:ImageFont.truetype(font,n)
def xy(x,y):return x*1100/600,1100-y*1100/600
for ox,oy,_,_ in sc['ore']:
 x,y=xy(ox,oy);draw.polygon([(x,y-5),(x+5,y),(x,y+5),(x-5,y)],fill='#ffcc70')
for i,(ox,oy) in enumerate(sc['starts'],1):
 x,y=xy(ox,oy);draw.ellipse((x-18,y-18,x+18,y+18),fill='#142834',outline='#e6e0c3',width=2);draw.text((x,y),str(i),font=f(23),anchor='mm',fill='white')
colors=['#fbc86a','#64dacd','#f59677'];labels=['AIRFIELD','SHIPYARD','ARSENAL']
for i,(r,_,_) in enumerate(json.loads((W/'design.json').read_text())['supplies']):
 row=next(v for v in sc['facilities'] if v[0]==r+'_BEACON');x,y=xy(row[2],row[3]);draw.ellipse((x-16,y-16,x+16,y+16),fill='#142834',outline=colors[i],width=3);draw.text((x,y),chr(65+i),font=f(19),anchor='mm',fill=colors[i]);draw.text((x,y+26),labels[i],font=f(16),anchor='mm',fill=colors[i])
for sp in sc['supply_points']:
 x,y=xy(sp['x'],sp['y']);draw.rectangle((x-5,y-5,x+5,y+5),fill='#ffe6a1')
for gun in sc['coastal_guns']:
 x,y=xy(*gun['pad']);ax,ay=xy(*gun['aim']);d=np.hypot(ax-x,ay-y);draw.line((x,y,x+(ax-x)/d*27,y+(ay-y)/d*27),fill='#ff8a73',width=4)
mini=im.resize((512,512),Image.Resampling.LANCZOS)
for suffix in ['_art.tga','_pic.tga']:mini.save(D/name/(name+suffix))
im.save(D/'Black_Tide_Tactical_Map.png')
sheet=Image.new('RGB',(1760,1360),'#0c1b25');sheet.paste(im,(35,205));d=ImageDraw.Draw(sheet)
d.text((40,32),'BLACK TIDE',font=f(70),fill='#fff1d7');d.text((43,118),'SALVAGE WARS  /  SIX-PLAYER RAID ARCHIPELAGO',font=f(24),fill='#71d2c9');d.text((44,162),'600 x 600  |  21 ORE NODES  |  ROTATING CONTRACTS  |  VANILLA RED ALERT 3',font=f(18),fill='#9fb5bd')
x=1180
d.text((x,207),'RAID. CAPTURE. CASH OUT.',font=f(27),fill='#fff1d7')
rows=[('01  HIT THE WATER','#71d2c9',['Start with 2 Riptides + 1 Engineer.','Load the Engineer and raid an island.','Your first salvage appears in 60-75s.']),('02  WIN THE CONTRACT','#fbc86a',['Capture the flashing central relay.','Hold it for 45 seconds to get paid.','Cash + mixed-faction troops at home.']),('03  KEEP MOVING','#f59677',['Targets rotate between three islands.','Winners have a 120-second cooldown.','At 6 minutes, stronger rewards unlock.'])]
for i,(title,col,lines) in enumerate(rows):
 y=280+i*205;d.rounded_rectangle((x,y,1720,y+175),radius=10,fill='#142b36');d.text((x+20,y+18),title,font=f(24),fill=col)
 for j,s in enumerate(lines):d.text((x+20,y+65+j*30),s,font=f(19),fill='#c1cfd1')
d.text((x,925),'THREE REASONS TO FIGHT',font=f(23),fill='#fff1d7')
for i,s in enumerate(['A  AIRFIELD: Twinblade + Tengus','B  SHIPYARD: Stingray + Riptides','C  ARSENAL: mixed assault squad']):d.text((x,970+i*36),s,font=f(20),fill=colors[i])
d.text((x,1100),'First contract win per island adds a gun',font=f(19),fill='#c1cfd1');d.text((x,1130),'that bombards the central sea.',font=f(19),fill='#c1cfd1')
d.text((x,1190),'English-only in-game notifications.',font=f(19),fill='#71d2c9');d.text((x,1223),'Standard skirmish elimination rules.',font=f(19),fill='#9fb5bd')
d.text((40,1320),'Terrain-derived planning view, not an in-game screenshot. Independent map; previous maps are preserved.',font=f(17),fill='#829aa5')
sheet.save(D/'Black_Tide_Play_Guide.png');print('Native previews and play guide saved')
