import sys, pathlib, json, copy
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from mapio import Map, R as BaseR, P
class R(BaseR):
 def s(self):return self.n(self.u('H')).decode('latin1')
def string(s):
 b=s.encode('latin1');return P('H',len(b))+b

def read_tree(m, chunk):
 name,ver,data=chunk;r=R(data);o={'kind':name,'ver':ver}
 if name=='ScriptGroup':o.update(name=r.s(),active=r.u('B'),sub=r.u('B'))
 elif name=='Script':
  o['strings']=[r.s() for _ in range(4)];o['flags']=list(r.n(6))
  if ver>=2:o['interval']=r.u('I')
  if ver==5:o['interval_type']=[r.u('B'),r.u('I')]
  if ver>=3:o['sequential']=[r.u('B'),r.u('B'),r.u('i'),r.u('B'),r.s()]
  if ver>=4:o['unknown']=r.s()
  if ver>=6:o['extra']=[r.u('i'),r.u('H')]
 elif name in ['Condition','ScriptAction','ScriptActionFalse']:
  cond=name=='Condition';o['opcode']=r.u('I')
  if ver>=(4 if cond else 2):o['keytype']=r.u('B');o['key']=m.names[int.from_bytes(r.n(3),'little')]
  o['args']=[]
  for _ in range(r.u('I')):
   typ=r.u('I')
   a=[typ,*[r.u('f') for _ in range(3)]] if typ==16 else [typ,r.u('i'),r.u('f'),r.s()]
   o['args'].append(a)
  if ver>=(5 if cond else 3):o['enabled']=r.u('I')
  if cond and ver>=5:o['invert']=r.u('I')
  assert r.p==len(data),(name,ver,r.p,len(data));return o
 o['children']=[read_tree(m,c) for c in m.chunks_read(r.n(len(data)-r.p))]
 return o

def write_tree(m,o):
 name=o['kind'];ver=o['ver'];b=b''
 if name=='ScriptGroup':b=string(o['name'])+bytes([o['active'],o['sub']])
 elif name=='Script':
  b=b''.join(string(s) for s in o['strings'])+bytes(o['flags'])
  if ver>=2:b+=P('I',o['interval'])
  if ver==5:b+=P('BI',*o['interval_type'])
  if ver>=3:b+=P('BBiB',*o['sequential'][:4])+string(o['sequential'][4])
  if ver>=4:b+=string(o['unknown'])
  if ver>=6:b+=P('iH',*o['extra'])
 elif name in ['Condition','ScriptAction','ScriptActionFalse']:
  b=P('I',o['opcode'])
  if 'key' in o:b+=P('B',o['keytype'])+m.key(o['key']).to_bytes(3,'little')
  b+=P('I',len(o['args']))
  for a in o['args']:b+=P('I',a[0])+(P('3f',*a[1:]) if a[0]==16 else P('if',a[1],a[2])+string(a[3]))
  if 'enabled' in o:b+=P('I',o['enabled'])
  if 'invert' in o:b+=P('I',o['invert'])
 b+=b''.join(write_tree(m,c) for c in o.get('children',[]))
 return m.chunk([name,ver,b])

def walk(o):
 yield o
 for c in o.get('children',[]):yield from walk(c)

if __name__=='__main__':
 m=Map('work/tokyo.map');tree=read_tree(m,m.get('PlayerScriptsList'))
 assert write_tree(m,tree)==m.chunk(m.get('PlayerScriptsList'))
 out=pathlib.Path('work/black_tide/reference')
 (out/'tokyo-scripts.json').write_text(json.dumps(tree,indent=2))
 catalog={}
 for o in walk(tree):
  if 'key' in o:catalog.setdefault(o['key'],o)
 (out/'script-catalog.json').write_text(json.dumps(catalog,indent=2))
 for k,o in sorted(catalog.items()):print(k,o['opcode'],o['args'])
