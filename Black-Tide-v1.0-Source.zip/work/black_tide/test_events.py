"""Behavioral interpreter for the delivered native map. This is not engine QA."""
import pathlib,json,random,xml.etree.ElementTree as ET
from scriptio import Map,read_tree,write_tree,walk
from areas import parse
W=pathlib.Path('work/black_tide');path=pathlib.Path('outputs/黑潮_夺宝战争/Black_Tide_6P/Black_Tide_6P.map')
m=Map(path);tree=read_tree(m,m.get('PlayerScriptsList'));scripts=tree['children'][0]['children'];cat=json.loads((W/'reference/script-catalog.json').read_text());areas=parse(m.get('TriggerAreas')[2]);objs=m.objects()
assert len(areas)==3 and len(tree['children'])==17
assert write_tree(m,tree)==m.chunk(m.get('PlayerScriptsList'))
assert len({s['strings'][0] for s in scripts})==len(scripts)
wp={o['props']['waypointName'][1] for o in objs if 'waypointName' in o['props']};area_names={a['name'] for a in areas}
localized=(path.parent/'map.str').read_bytes();assert localized.isascii() and b'\0' not in localized and not localized.startswith(b'\xef\xbb\xbf')
asset_ids=set()
for p in (W/'reference').glob('*.xml'):
 for e in ET.parse(p).getroot().iter():
  if e.tag.split('}')[-1]=='GameObject' and 'id' in e.attrib:asset_ids.add(e.attrib['id'].lower())
asset_ids|={o['type'].lower() for source in ['work/base.map','work/tokyo.map'] for o in Map(source).objects()}
for n in walk(tree):
 if 'key' not in n:continue
 ref=cat[n['key']];assert (n['opcode'],n['ver'],n['keytype'])==(ref['opcode'],ref['ver'],ref['keytype']);assert [a[0] for a in n['args']]==[a[0] for a in ref['args']]
 assert n['key'] not in ['DISPLAY_COUNTDOWN_TIMER','DISABLE_INPUT','CAMERA_LETTERBOX_BEGIN','MOVIE_PLAY_FULLSCREEN']
 for a in n['args']:
  if a[0]==7:assert a[3] in wp
  if a[0]==9:assert a[3] in area_names
  if a[0]==15:assert a[3] in asset_ids,('Unknown EA object',a[3])
 if n['key']=='SHOW_MILITARY_CAPTION':assert n['args'][0][3].encode() in localized and n['args'][1][2]==5.
S=lambda n,i:n['args'][i][3]
I=lambda n,i:n['args'][i][1]
F=lambda n,i:n['args'][i][2]
def run(seed=1,duration=1200,mode='normal',active=(1,2,3,4,5,6),force_loot=None):
 rng=random.Random(seed);counters={};timers={};flags={};named={};off=set();reveals=set();captions=[];cash=[];units=[];drops=[];wins=[];salvage=[];guns=[];arrival=-999;open_at=-999;hold_at={};last_win={};claims=[]
 regions=['NORTH','WEST','SOUTH']
 def owner(name,t):
  ri=regions.index(name.removesuffix('_BEACON'))+1
  if mode=='neutral' or mode=='destroyed':return 0
  if mode=='handover':
   age=t-open_at
   return 1 if age<30 else (0 if age<35 else 2)
  if mode=='cooldown_capture':return 1 if t-open_at<20 else 2
  return (ri-1)%len(active)+1 if active==tuple(range(1,len(active)+1)) else active[0]
 def present(t):
  if mode in ['absent','destroyed'] or t-arrival<7:return set()
  return set(active) if mode=='tie' else {active[seed%len(active)]}
 def cond(n,t):
  k=n['key'];v=False
  if k=='CONDITION_TRUE':v=True
  elif k=='COUNTER':
   a,b=counters.get(S(n,0),0),I(n,2);v=[a<b,a<=b,a==b,a>=b,a>b,a!=b][I(n,1)]
  elif k=='TIMER_EXPIRED':v=t>=timers.get(S(n,0),float('inf'))
  elif k=='FLAG':v=flags.get(S(n,0),False)==bool(I(n,1))
  elif k=='NAMED_NOT_DESTROYED':v=S(n,0) in named or (S(n,0).endswith('_BEACON') and mode!='destroyed')
  elif k=='NAMED_OWNED_BY_PLAYER':v=S(n,0)=='Player_'+str(owner(S(n,1),t))
  elif k=='PLAYER_HAS_OBJECT_COMPARISON':v=int(S(n,0).split('_')[1]) in active
  elif k=='SKIRMISH_PLAYER_HAS_UNITS_IN_AREA':v=S(n,1)=='SS_LOOT_AREA_'+str(counters.get('SS_SITE',0)) and int(S(n,0).split('_')[1]) in present(t)
  else:raise AssertionError(k)
  return not v if n.get('invert') else v
 for t in range(duration+1):
  if mode=='destroyed':named.pop('SS_DROP_MARKER',None)
  for ix,s in enumerate(scripts):
   if ix in off or not all(cond(n,t) for n in s['children'][0]['children']):continue
   name=s['strings'][0]
   if s['flags'][1]:off.add(ix)
   if name.startswith('BT_OPEN_'):open_at=t
   if name.startswith('BT_HOLD_'):hold_at[(counters['BT_TARGET'],int(name.split('_')[-1]))]=t
   if name.startswith('BT_WIN_'):
    p=counters['BT_OWNER'];ri=counters['BT_TARGET']
    assert t-hold_at[(ri,p)]>=45
    assert t-open_at<150
    assert owner(regions[ri-1]+'_BEACON',t)==p
    assert t-last_win.get(p,-1000)>=120,'Contract cooldown bypassed'
    if mode=='handover':assert p==2 and t-open_at>=80
    last_win[p]=t;wins.append((t,p,ri,counters['BT_TIER']))
   if name.startswith('SS_AWARD_'):
    p=counters['SS_WINNER'];assert p in present(t) and t-arrival<70
    if mode=='tie':
     priority=counters['SS_PRIORITY'];order=[(priority-1+j)%6+1 for j in range(6)];assert p==next(x for x in order if x in active)
    salvage.append((t,p,counters['SS_LOOT']))
   for n in s['children'][1:]:
    k=n['key']
    if k=='SET_COUNTER':counters[S(n,0)]=I(n,1)
    elif k=='SET_FLAG':flags[S(n,0)]=bool(I(n,1))
    elif k=='SET_TIMER':timers[S(n,0)]=t+I(n,1)
    elif k=='SET_RANDOM_MSEC_TIMER':timers[S(n,0)]=t+rng.uniform(F(n,1),F(n,2))
    elif k=='SET_RANDOM_COUNTER':counters[S(n,0)]=force_loot if S(n,0)=='SS_LOOT' and force_loot else rng.randint(I(n,1),I(n,2))
    elif k in ['CREATE_NAMED_ON_TEAM_AT_WAYPOINT','CREATE_NAMED_ON_TEAM_AT_WAYPOINT_WITH_ORIENTATION']:
     uid=S(n,0);assert uid not in named;named[uid]=S(n,1)
     if uid=='SS_DROP_MARKER':arrival=t;drops.append((t,counters['SS_SITE']))
     else:assert uid.startswith('BT_COASTAL_');guns.append((t,uid,S(n,2)))
    elif k=='CREATE_UNNAMED_ON_TEAM_AT_WAYPOINT':
     p=int(S(n,1).split('/')[0].split('_')[1]);assert p in active
     assert S(n,2).startswith(f'BT_HOME_{p}_');units.append((t,p,S(n,0),name))
    elif k=='PLAYER_GIVE_MONEY':cash.append((t,S(n,0),I(n,1)))
    elif k=='NAMED_DELETE':assert S(n,0) in named;del named[S(n,0)]
    elif k=='MAP_REVEAL_PERMANENTLY_AT_WAYPOINT':assert S(n,3) not in reveals;reveals.add(S(n,3))
    elif k=='MAP_UNDO_REVEAL_PERMANENTLY_AT_WAYPOINT':assert S(n,0) in reveals;reveals.remove(S(n,0))
    elif k=='SHOW_MILITARY_CAPTION':captions.append((t,S(n,0)))
    elif k=='NAMED_FORCE_ATTACK_WAYPOINT':assert S(n,0) in named
    elif k in ['NAMED_FLASH','OBJECT_CREATE_RADAR_EVENT','OBJECTLIST_ADDOBJECTTYPE']:pass
    else:raise AssertionError(k)
  assert len(guns)<=3 and len(reveals)<=2
 assert len({t for t,_,_ in salvage})==len(salvage)
 assert len({t for t,*_ in wins})==len(wins)
 assert all(b[0]-a[0]>=6 for a,b in zip(captions,captions[1:]))
 assert sum(n.startswith('BT_START_') for *_,n in units)==len(active)*3
 if mode in ['neutral','destroyed']:assert not wins and not guns
 elif duration>400:assert wins
 if mode in ['absent','destroyed']:assert not salvage
 else:assert salvage
 if mode=='normal' and duration>500:assert {t for *_,t in wins}=={1,2}
 return dict(contract_wins=len(wins),salvage_claims=len(salvage),supply_events=len(drops),guns=len(guns),starter_units=len(active)*3,captions=len(captions),sites=sorted({s for _,s in drops}),loot=sorted({l for _,_,l in salvage}),winners=sorted({p for _,p,*_ in wins}))
results={}
for seed in range(1,7):results[f'seed_{seed}']=run(seed=seed)
for mode in ['absent','destroyed','neutral','tie','handover','cooldown_capture']:results[mode]=run(mode=mode)
results['two_players_closed_slots']=run(active=(1,2))
for loot in range(1,7):results[f'loot_{loot}']=run(duration=300,mode='neutral',force_loot=loot)
assert set.union(*(set(v['sites']) for v in results.values()))=={1,2,3}
assert set.union(*(set(v['loot']) for v in results.values()))==set(range(1,7))
report=dict(status='PASS',script_count=len(scripts),scenarios=results,ascii_strings=True,verified_ea_assets=len(asset_ids),persistent_panels=False,limitations='Behavior model and geometry checks, not RA3 runtime proof; native RNG is modeled with seeded RNG.')
(W/'event-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
