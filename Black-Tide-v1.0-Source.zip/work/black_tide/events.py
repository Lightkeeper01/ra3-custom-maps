"""Black Tide: native, synchronized, bounded skirmish events. ASCII localization."""
import json,copy,pathlib
from scriptio import read_tree,write_tree
ROOT=pathlib.Path('work/black_tide')
CAT=json.loads((ROOT/'reference/script-catalog.json').read_text())
def command(key,*values):
 o=copy.deepcopy(CAT[key]);assert len(values)==len(o['args']),(key,values)
 for a,v in zip(o['args'],values):
  if isinstance(v,str):a[3]=v.lower() if a[0]==15 else v
  elif isinstance(v,float):a[2]=v
  else:a[1]=int(v)
 o['enabled']=1
 if o['kind']=='Condition':o['invert']=0
 else:o['kind']='ScriptAction'
 return o
def script(name,conditions,actions,once=False):
 return dict(kind='Script',ver=4,strings=[name,'Black Tide authored event.','',''],flags=[1,int(once),1,1,1,0],interval=1,sequential=[0,0,0,1,''],unknown='X',children=[dict(kind='OrCondition',ver=1,children=conditions)]+actions)
def install_events(m,cfg):
 c=command;steps=[];strings={};messages={}
 def add(name,cond,actions,once=False):steps.append(script(name,cond,actions,once))
 def msg(key,text):
  assert text.isascii() and len(text)<=110
  if key not in messages:messages[key]=len(messages)+1;strings['MSN:BLACKTIDE:'+key]=text
  return c('SET_COUNTER','BT_MESSAGE',messages[key])
 def eq(k,v):return c('COUNTER',k,2,v)
 def ne(k,v):return c('COUNTER',k,5,v)
 def invert(o):o['invert']=1;return o
 def exists(n):return c('NAMED_NOT_DESTROYED',n)
 def owns(p,n):return c('NAMED_OWNED_BY_PLAYER',f'Player_{p}',n)
 def team(p):return f'Player_{p}/teamPlayer_{p}'
 def spawn(p,units):return [c('CREATE_UNNAMED_ON_TEAM_AT_WAYPOINT',u,team(p),f'BT_HOME_{p}_{i%4+1}') for i,u in enumerate(units)]
 labels={'NORTH':'AIRFIELD','WEST':'SHIPYARD','SOUTH':'ARSENAL'}
 sites=[(r,f'SS_{r}_DROP_1') for r,_,_ in cfg['supplies']]
 init=[c('SET_COUNTER','BT_MESSAGE',0),c('SET_TIMER','BT_NOTICE',0),c('SET_TIMER','BT_INTRO',8),c('SET_TIMER','BT_HELP',18),c('SET_TIMER','BT_START',7),c('SET_TIMER','BT_START_END',20),c('SET_COUNTER','BT_TIER',1),c('SET_TIMER','BT_ESCALATE',360),c('SET_COUNTER','SS_PHASE',0),c('SET_RANDOM_MSEC_TIMER','SS_EVENT',50.,65.),c('SET_COUNTER','BT_CONTRACT_PHASE',0),c('SET_RANDOM_COUNTER','BT_TARGET',1,3),c('SET_TIMER','BT_CONTRACT',85),c('SET_COUNTER','BT_OWNER',0)]
 for typ in ['AlliedMCV','SovietMCV','JapanMCV','AlliedConstructionYard','SovietConstructionYard','JapanConstructionYard']:init.append(c('OBJECTLIST_ADDOBJECTTYPE',typ,'BT_BASE_TYPES'))
 for p in range(1,7):init.append(c('SET_TIMER',f'BT_COOLDOWN_{p}',0))
 for r,_ in sites:init.append(c('SET_FLAG','BT_GUN_'+r,False))
 add('BT_INIT',[c('CONDITION_TRUE')],init,True)
 add('BT_INTRO',[c('TIMER_EXPIRED','BT_INTRO')],[msg('INTRO','BLACK TIDE | Your raid squad is ready. Use Riptides + Engineer to raid the three central islands.')],True)
 add('BT_HELP',[c('TIMER_EXPIRED','BT_HELP')],[msg('HELP','Capture the FLASHING relay with an Engineer. Hold 45s for cash + a strike squad. Watch the radar!')],True)
 for p in range(1,7):
  # Closed slots never receive units, and defeated players are not resurrected later.
  add(f'BT_START_{p}',[c('TIMER_EXPIRED','BT_START'),invert(c('TIMER_EXPIRED','BT_START_END')),c('PLAYER_HAS_OBJECT_COMPARISON',f'Player_{p}',4,0,'BT_BASE_TYPES')],spawn(p,['AlliedAntiInfantryVehicle','AlliedAntiInfantryVehicle','AlliedEngineer']),True)
 add('BT_ESCALATION',[c('TIMER_EXPIRED','BT_ESCALATE')],[c('SET_COUNTER','BT_TIER',2),msg('ESCALATION','ARMS RACE | Contracts now pay $2200 and stronger squads. All three relays remain in play.')],True)
 # Fast, recurring salvage. One live cache; each event rolls its site independently.
 add('SS_ROLL',[eq('SS_PHASE',0),c('TIMER_EXPIRED','SS_EVENT')],[c('SET_RANDOM_COUNTER','SS_SITE',1,3),c('SET_RANDOM_COUNTER','SS_LOOT',1,6),c('SET_RANDOM_COUNTER','SS_PRIORITY',1,6),c('SET_COUNTER','SS_PHASE',1)])
 for si,(r,wp) in enumerate(sites,1):
  add(f'SS_WARN_{si}',[eq('SS_PHASE',1),eq('SS_SITE',si)],[msg('WARN_'+r,f'SALVAGE | {labels[r]} drop in 10s. Bring a unit to the marked supply pad.'),c('MAP_REVEAL_PERMANENTLY_AT_WAYPOINT',wp,22.,'<All Players>','BT_CACHE_VISION'),c('SET_COUNTER','SS_PHASE',2),c('SET_TIMER','SS_EVENT',10)])
  add(f'SS_ARRIVE_{si}',[eq('SS_PHASE',2),eq('SS_SITE',si),c('TIMER_EXPIRED','SS_EVENT')],[c('CREATE_NAMED_ON_TEAM_AT_WAYPOINT','SS_DROP_MARKER','TH_JapanCrate01','SkirmishNeutral/teamSkirmishNeutral',wp),c('NAMED_FLASH','SS_DROP_MARKER',65),c('OBJECT_CREATE_RADAR_EVENT','SS_DROP_MARKER',0),msg('DROP_'+r,f'SALVAGE LIVE | {labels[r]}: move close to the FLASHING cache to claim. Expires in 70s.'),c('SET_COUNTER','SS_PHASE',3),c('SET_TIMER','SS_EVENT',70)])
 add('SS_EXPIRE',[eq('SS_PHASE',3),c('TIMER_EXPIRED','SS_EVENT')],[c('SET_COUNTER','SS_PHASE',5)])
 add('SS_DESTROYED',[eq('SS_PHASE',3),invert(exists('SS_DROP_MARKER'))],[c('SET_COUNTER','SS_PHASE',5)])
 for priority in range(1,7):
  for offset in range(6):
   p=(priority-1+offset)%6+1
   for si,(_,wp) in enumerate(sites,1):
    add(f'SS_CLAIM_{priority}_{p}_{si}',[eq('SS_PHASE',3),eq('SS_SITE',si),eq('SS_PRIORITY',priority),c('SKIRMISH_PLAYER_HAS_UNITS_IN_AREA',f'Player_{p}',f'SS_LOOT_AREA_{si}')],[c('SET_COUNTER','SS_WINNER',p),c('SET_COUNTER','SS_PHASE',4)])
 rewards={1:dict(name='$1000',cash=1000),2:dict(name='$1800',cash=1800),3:dict(name='2 Riptides',units=['AlliedAntiInfantryVehicle']*2),4:dict(name='2 Tengus',units=['JapanAntiInfantryVehicle']*2),5:dict(name='Twinblade',units=['SovietAntiGroundAircraft']),6:dict(name='Engineer + Riptide',units=['AlliedEngineer','AlliedAntiInfantryVehicle'])}
 for loot,reward in rewards.items():
  for p in range(1,7):
   actions=[c('NAMED_DELETE','SS_DROP_MARKER')]
   if 'cash' in reward:actions.append(c('PLAYER_GIVE_MONEY',f'Player_{p}',reward['cash']))
   else:actions+=spawn(p,reward['units'])
   actions += [msg(f'LOOT_{p}_{loot}',f'P{p} SALVAGE: {reward["name"]}'+('.' if 'cash' in reward else ' delivered to home beach.')),c('SET_COUNTER','SS_PHASE',5)]
   add(f'SS_AWARD_{loot}_{p}',[eq('SS_PHASE',4),eq('SS_WINNER',p),eq('SS_LOOT',loot)],actions)
 add('SS_DELETE',[eq('SS_PHASE',5),exists('SS_DROP_MARKER')],[c('NAMED_DELETE','SS_DROP_MARKER')])
 add('SS_END',[eq('SS_PHASE',5)],[c('MAP_UNDO_REVEAL_PERMANENTLY_AT_WAYPOINT','BT_CACHE_VISION'),c('SET_COUNTER','SS_PHASE',0),c('SET_RANDOM_MSEC_TIMER','SS_EVENT',45.,75.)])
 # One highlighted contract. Round-robin rotation forces movement; a private 120s
 # cooldown after payout prevents the same player immediately taking another.
 for ri,(r,wp) in enumerate(sites,1):
  beacon=r+'_BEACON';gun=cfg['coastal_guns'][ri-1]
  live=[eq('BT_CONTRACT_PHASE',1),eq('BT_TARGET',ri)]
  add('BT_OPEN_'+r,[eq('BT_CONTRACT_PHASE',0),eq('BT_TARGET',ri),c('TIMER_EXPIRED','BT_CONTRACT'),exists(beacon)],[c('SET_COUNTER','BT_CONTRACT_PHASE',1),c('SET_COUNTER','BT_OWNER',0),c('SET_TIMER','BT_CONTRACT',150),c('MAP_REVEAL_PERMANENTLY_AT_WAYPOINT',wp,65.,'<All Players>','BT_OBJECTIVE_VISION'),c('NAMED_FLASH',beacon,150),c('OBJECT_CREATE_RADAR_EVENT',beacon,0),msg('OPEN_'+r,f'CONTRACT | {labels[r]}: capture the FLASHING relay, hold 45s. Win cash + strike squad!')])
  add('BT_SKIP_'+r,[eq('BT_CONTRACT_PHASE',0),eq('BT_TARGET',ri),c('TIMER_EXPIRED','BT_CONTRACT'),invert(exists(beacon))],[c('SET_COUNTER','BT_TARGET',ri%3+1),c('SET_TIMER','BT_CONTRACT',10)])
  # Close before any payout at the deadline, even if the hold completes that tick.
  add('BT_TIMEOUT_'+r,live+[c('TIMER_EXPIRED','BT_CONTRACT')],[msg('TIMEOUT_'+r,labels[r]+' contract expired. A new target opens in 20s.'),c('SET_COUNTER','BT_CONTRACT_PHASE',2)])
  add('BT_LOST_'+r,live+[invert(exists(beacon))],[msg('LOST_'+r,labels[r]+' relay destroyed. Contract moves to another island.'),c('SET_COUNTER','BT_CONTRACT_PHASE',2)])
  for p in range(1,7):
   add(f'BT_HOLD_{r}_{p}',live+[exists(beacon),owns(p,beacon),ne('BT_OWNER',p),c('TIMER_EXPIRED',f'BT_COOLDOWN_{p}')],[c('SET_COUNTER','BT_OWNER',p),c('SET_TIMER','BT_HOLD',45),c('SET_TIMER','BT_HALFWAY',25),c('SET_FLAG','BT_PROGRESS',False),msg(f'HOLD_{r}_{p}',f'P{p} is claiming {labels[r]}! 45s to stop them: capture or destroy the relay.')])
  add('BT_RESET_'+r,live+[ne('BT_OWNER',0)]+[invert(owns(p,beacon)) for p in range(1,7)],[c('SET_COUNTER','BT_OWNER',0),msg('RESET_'+r,labels[r]+' control interrupted! Claim progress reset.')])
  # A capture by an owner still on cooldown must cancel the previous owner's hold.
  for p in range(1,7):
   add(f'BT_CANCEL_{r}_{p}',live+[eq('BT_OWNER',p),invert(owns(p,beacon))],[c('SET_COUNTER','BT_OWNER',0)])
   add(f'BT_PROGRESS_{r}_{p}',live+[eq('BT_OWNER',p),owns(p,beacon),c('TIMER_EXPIRED','BT_HALFWAY'),c('FLAG','BT_PROGRESS',False)],[c('SET_FLAG','BT_PROGRESS',True),msg(f'PROGRESS_{r}_{p}',f'P{p}: {labels[r]} shipment unlocks in 20s. Defend the relay!')])
   for tier in [1,2]:
    bundles={
     'NORTH':['SovietAntiGroundAircraft']+['JapanAntiInfantryVehicle']*(1 if tier==1 else 2),
     'WEST':['AlliedAntiInfantryVehicle']*(2 if tier==1 else 1)+['SovietAntiNavyShipTech1']*(1 if tier==1 else 2),
     'SOUTH':['JapanAntiInfantryVehicle']*(2 if tier==1 else 3)+['AlliedAntiInfantryVehicle']}
    cond=live+[eq('BT_OWNER',p),exists(beacon),owns(p,beacon),c('TIMER_EXPIRED','BT_HOLD'),eq('BT_TIER',tier)]
    cash=1500 if tier==1 else 2200
    add(f'BT_WIN_{r}_{p}_{tier}',cond,spawn(p,bundles[r])+[c('PLAYER_GIVE_MONEY',f'Player_{p}',cash),c('SET_COUNTER','BT_CONTRACT_PHASE',2),c('SET_COUNTER','BT_GUN_WINNER',p),c('SET_COUNTER','BT_GUN_TARGET',ri),c('SET_TIMER',f'BT_COOLDOWN_{p}',120),msg(f'WIN_{r}_{p}_{tier}',f'P{p} WON {labels[r]}! ${cash} + strike squad at home beach. P{p} contracts cooldown: 120s.')])
   uid='BT_COASTAL_'+r
   add(f'BT_GUN_{r}_{p}',[eq('BT_CONTRACT_PHASE',2),eq('BT_GUN_TARGET',ri),eq('BT_GUN_WINNER',p),c('FLAG','BT_GUN_'+r,False)],[c('CREATE_NAMED_ON_TEAM_AT_WAYPOINT_WITH_ORIENTATION',uid,'BB_EuropeCoastalGun',team(p),'SS_GUN_'+r+'_PAD',float(gun['orientation'])),c('NAMED_FORCE_ATTACK_WAYPOINT',uid,'SS_GUN_'+r+'_AIM'),c('NAMED_FLASH',uid,12),c('SET_FLAG','BT_GUN_'+r,True)])
  add('BT_UNFLASH_'+r,[eq('BT_CONTRACT_PHASE',2),eq('BT_TARGET',ri),exists(beacon)],[c('NAMED_FLASH',beacon,1)])
  add('BT_CLOSE_'+r,[eq('BT_CONTRACT_PHASE',2),eq('BT_TARGET',ri)],[c('MAP_UNDO_REVEAL_PERMANENTLY_AT_WAYPOINT','BT_OBJECTIVE_VISION'),c('SET_COUNTER','BT_CONTRACT_PHASE',0),c('SET_COUNTER','BT_TARGET',ri%3+1),c('SET_COUNTER','BT_GUN_TARGET',0),c('SET_COUNTER','BT_GUN_WINNER',0),c('SET_COUNTER','BT_OWNER',0),c('SET_TIMER','BT_CONTRACT',20)])
 for key,number in messages.items():
  add('BT_NOTICE_'+key,[eq('BT_MESSAGE',number),c('TIMER_EXPIRED','BT_NOTICE')],[c('SHOW_MILITARY_CAPTION','MSN:BLACKTIDE:'+key,5.),c('SET_COUNTER','BT_MESSAGE',0),c('SET_TIMER','BT_NOTICE',6)])
 tree=read_tree(m,m.get('PlayerScriptsList'));assert len(tree['children'])==17 and all(not o.get('children') for o in tree['children'])
 tree['children'][0]['children']=steps;encoded=write_tree(m,tree);m.get('PlayerScriptsList')[2]=encoded[10:];assert write_tree(m,read_tree(m,m.get('PlayerScriptsList')))==encoded
 (ROOT/'event-tree.json').write_text(json.dumps(tree,indent=2))
 report=dict(version='1.0',script_count=len(steps),supply_sites=3,first_supply=[60,75],repeat_wait=[45,75],hold_seconds=45,contract_window=150,winner_cooldown=120,escalation=360,max_live_cache=1,max_guns=3,english_only=True,caption_seconds=5,caption_interval=6,starter=['2 Riptides','1 Engineer'],rewards=rewards,win_rule='Standard skirmish elimination')
 return report,'\r\n\r\n'.join(f'{k}\r\n"{v}"\r\nEND' for k,v in strings.items())+'\r\n'
