# Black Tide - Salvage Wars [6P] - source bundle

A compact six-player island arena with an opening raid squad, rotating relay contracts, random salvage, mixed-faction reinforcements and coastal artillery.

This is the corresponding map-generation source archive. Extract it into an empty working directory. All `work/...` paths are relative to that directory; run from the archive root. Use Python 3.11 with numpy, scipy and Pillow installed. Original asset and format-reference licenses are included.

Run these commands in order:

```sh
python3 work/black_tide/build.py
python3 work/black_tide/validate.py
python3 work/black_tide/test_events.py
python3 work/black_tide/preview.py
python3 work/black_tide/package.py
```

The archive retains original project paths and developer documents, some of which are in Chinese. The public player ZIP has an English installation guide. Do not run a generator inside a directory containing work you want to preserve.

Experimental release. Geometry and 19 event-model scenarios passed; a source archive rebuild was byte-identical. In-game rendering, balance and multiplayer behavior still need playtesting.
