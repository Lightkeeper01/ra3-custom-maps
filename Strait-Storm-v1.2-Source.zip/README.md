# Strait Storm - Wild Supplies [6P] - source bundle

A larger 760 x 760 six-player archipelago with 34 ore nodes, 15 possible salvage locations, eight capturable facilities and coastal-gun challenges.

This is the corresponding map-generation source archive. Extract it into an empty working directory. All `work/...` paths are relative to that directory; run from the archive root. Use Python 3.11 with numpy, scipy and Pillow installed. Original asset and format-reference licenses are included.

Run these commands in order:

```sh
python3 work/strait_storm/build.py
python3 work/strait_storm/validate.py
python3 work/strait_storm/test_events.py
python3 work/strait_storm/preview.py
python3 work/strait_storm/package.py
```

The archive retains original project paths and developer documents, some of which are in Chinese. The public player ZIP has an English installation guide. Do not run a generator inside a directory containing work you want to preserve.

Experimental release. File, geometry and event-model checks passed. The randomized v1.2 revision has not completed an in-game playtest. Legacy Chinese event captions may not render correctly on all installations.
