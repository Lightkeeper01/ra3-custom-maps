import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mapio import *
import numpy as np, math, copy, random, collections
import xml.etree.ElementTree as ET
from storm_grid import snap, DIAGONALS, phases_for_height
from scipy.ndimage import gaussian_filter, distance_transform_edt, map_coordinates
from PIL import Image, ImageDraw, ImageFont
random.seed(9310); rng=np.random.default_rng(9310)
CFG=json.loads(pathlib.Path('work/strait_storm/design.json').read_text())
OUT=pathlib.Path('outputs/海峡风暴_群岛争锋/Strait_Storm_6P');OUT.mkdir(parents=True,exist_ok=True)
m=Map('work/base.map');tok=Map('work/tokyo.map');extra=Map('work/strait_storm/reference/CAMP_S04_Geneva_Bass.map');brighton=Map('work/strait_storm/reference/CAMP_A01_BrightonBeach_Smith.map');templates={o['type']:o for o in m.objects()+tok.objects()+extra.objects()+brighton.objects()}
for typ in ['VeterancyTechStructure','ShipYardTechStructure','GarageTechStructure','AirportTechStructure']:templates.setdefault(typ,copy.deepcopy(templates['HospitalTechStructure']))
N=820;B=30;S=760;Y,X=np.mgrid[-B:N-B,-B:N-B];sea=200.
# Authored game-scale coastline. No operational or infrastructure coordinates.
polys=CFG['polys']
land=np.zeros((N,N),bool);regions=np.zeros((N,N),np.uint8)
for i,(name,pts) in enumerate(polys.items(),1):
 im=Image.new('1',(N,N));ImageDraw.Draw(im).polygon([(x+B,y+B) for x,y in pts],fill=1);mask=np.array(im,dtype=bool);land|=mask;regions[mask]=i
land=gaussian_filter(land.astype(float),1.3)>.5
inside=distance_transform_edt(land);outside=distance_transform_edt(~land);signed=inside-outside
noise=gaussian_filter(rng.normal(size=(N,N)),5);noise/=noise.std()
fine=gaussian_filter(rng.normal(size=(N,N)),1.2);fine/=fine.std()
height=sea+np.clip(signed*2.1,-105,30)+np.clip((inside-11)/8,0,1)*(noise*2.2+fine*.55)
# Central mountain spine and coastal hills, sculpted from overlapping ridges.
ridge=np.zeros_like(height)
for x,y,amp,sx,sy in [(457,482,125,13,37),(441,415,155,14,44),(423,347,112,12,35),(407,293,75,11,25),(49,435,83,19,51),(54,217,90,18,47),(67,600,70,19,46),(276,711,30,20,9),(700,679,40,12,15),(707,338,38,12,13),(620,75,34,15,13)]:
 ridge+=amp*np.exp(-.5*(((X-x)/sx)**2+((Y-y)/sy)**2))
ridge*=np.clip((inside-8)/12,0,1)
ridge*=np.clip(.80+.13*noise+.04*fine,.55,1.2)
# Two readable passages through Taiwan's mountains.
for cy in [357,474]:ridge*=1-.83*np.exp(-((Y-cy)/6)**2)*(regions==2)
height+=ridge
starts=CFG['starts']
# Clear, flat deployment discs: same buildable footprint for all six seats.
for x,y in starts:
 d=np.hypot(X-x,Y-y);t=np.clip((d-24)/12,0,1);t=t*t*(3-2*t);height=height*t+230*(1-t)
# Rural/urban plazas and industrial ports.
cities=CFG['cities']
for x,y,sx,sy in cities:
 d=np.maximum(abs(X-x)/sx,abs(Y-y)/sy);t=np.clip((d-.85)/.25,0,1);height=np.where(d<1.1,height*t+230*(1-t),height)
# Industrial quays extend from an existing coast; nearby beaches remain open.
ports=CFG['ports']
portmask=np.zeros_like(land)
for x,y,sx,sy in ports:
 pm=(abs(X-x)<sx)&(abs(Y-y)<sy);portmask|=pm;height[pm]=230
# Highway ribbons, painted as native terrain; no blocking bridge substitutes.
roads=[]
def road(points,width=1.6):
 for (ax,ay),(bx,by) in zip(points,points[1:]):
  t=np.clip(((X-ax)*(bx-ax)+(Y-ay)*(by-ay))/((bx-ax)**2+(by-ay)**2),0,1)
  d=np.hypot(X-(ax+t*(bx-ax)),Y-(ay+t*(by-ay)));roads.append(d<width)
road([(110,105),(119,202),(106,308),(132,390),(117,475),(144,564),(152,650)],2.2)
road([(390,217),(371,279),(379,349),(388,417),(400,477),(432,542)],2.0)
road([(383,357),(448,357),(473,376)],1.8)
road([(401,474),(461,474),(484,479)],1.8)
for x,y,sx,sy in cities:
 for dx in [-sx*.5,sx*.5]:road([(x+dx,y-sy),(x+dx,y+sy)],1.2)
 road([(x-sx,y),(x+sx,y)],1.6)
roadmask=np.logical_or.reduce(roads)&(height>218)&(ridge<12)
# Keep original registered terrain material table and build native blending records.
r=R(m.get('BlendTileData')[2]);oldarea=r.u('I');r.n(oldarea*8);oldbits=((660+7)//8)*660;r.n(oldbits*8+oldarea);a=N*N;bitbytes=((N+7)//8)*N
cellcount=r.u('I');oldblends=r.u('I');oldcliffs=r.u('I');nt=r.u('I');txstart=r.p;textures=[]
for _ in range(nt):
 vals=[r.u('I') for _ in range(4)];name=r.s();textures.append((vals,name))
txbytes=r.b[txstart:r.p];magic=r.n(8)
print('Textures:',[n for _,n in textures])
# Select only verified vanilla texture names present in this official map.
def ti(*q):
 for s in q:
  for i,(_,n) in enumerate(textures):
   if n==s:return i
 raise KeyError(q)
grass=ti('Grass_Yucatan05');grass2=ti('Grass_Yucatan06');sand=ti('Dirt_Yucatan01');rock=ti('Rock_Yucatan01');reef=ti('Reef_Havana01');pave=ti('Pavement_CapeCod02');dirt=ti('Dirt_CapeCod02')
typegrid=np.full((N,N),grass,np.int32);typegrid[noise>.5]=grass2;typegrid[noise<-.85]=ti('Grass_CapeCod17');typegrid[(height<220)]=sand;typegrid[height<193]=reef
slope=np.hypot(*np.gradient(height));typegrid[(ridge>24)|(slope>4.4)]=rock;typegrid[(ridge>12)&(ridge<26)]=dirt
urbanmask=np.zeros_like(land)
for x,y,sx,sy in cities:urbanmask|=(abs(X-x)<sx)&(abs(Y-y)<sy)
typegrid[urbanmask|portmask]=pave;typegrid[roadmask]=dirt
# 8x8 texture tile phase prevents uniform repeated microtiles.
tiles=(typegrid*64+((Y.astype(int)+B)%8)*8+(X.astype(int)+B)%8).astype('<u2')
blend=np.zeros((N,N),'<u2');desc=[];cache={}
# Blend toward one adjacent material on boundary; preserve solid interior islands.
for dy,dx,flags in [(0,1,0),(0,-1,0),(1,0,0),(-1,0,0)]:
 other=np.roll(typegrid,(-dy,-dx),(0,1));diff=(other!=typegrid)&(blend==0)
 for yy,xx in zip(*np.where(diff)):
  sec=int(other[yy,xx]*64+(yy%8)*8+xx%8)
  # Native horizontal/vertical blending with Flipped flag for negative axes.
  direction=b'\1\0\0\0' if dx else b'\0\1\0\0'
  flags=1 if dx<0 or dy<0 else 0
  key=(sec,direction,flags)
  if key not in cache:
   cache[key]=len(desc)+1;desc.append(P('I',sec)+direction+bytes([flags,0])+P('II',0xffffffff,0x7ada0000))
  blend[yy,xx]=cache[key]
zero=bytes(bitbytes)
impass=(slope>5.5)&(height>225)
# Base discs and quays are always passable.
for x,y in starts:impass[np.hypot(X-x,Y-y)<35]=False
impass[roadmask|portmask]=False
impbytes=np.packbits(impass,axis=1,bitorder='little').tobytes()
shrub=np.where((height>222)&(ridge<20)&~urbanmask&~portmask&~roadmask,20,0).astype('uint8')
m.get('BlendTileData')[2]=P('I',a)+tiles.tobytes()+blend.tobytes()+bytes(a*4)+impbytes+zero*3+bytes([255])*bitbytes+zero*3+shrub.tobytes()+P('IIII',cellcount,len(desc)+1,1,nt)+txbytes+magic+b''.join(desc)
h=P('9I',N,N,B,1,0,0,S,S,N*N);m.get('HeightMapData')[2]=h[:36]+np.rint(height/.0390625).clip(0,65535).astype('<u2').tobytes()
# Replace full-map water polygon while preserving compatible ocean shader.
r=R(m.get('StandingWaterAreas')[2]);r.u('I');uid=r.u('I');nm=r.s();layer=r.s();uv=r.u('f');add=r.u('B');bump=r.s();sky=r.s();npnt=r.u('I');r.n(npnt*8);wh=r.u('I');fx=r.s();depth=r.s()
m.get('StandingWaterAreas')[2]=P('II',1,1)+string('StraitOcean')+string('')+P('fB',uv,add)+string(bump)+string(sky)+P('I',4)+P('8f',-300,-300,7900,-300,7900,7900,-300,7900)+P('I',200)+string(fx)+string(depth)
# Neutral art uses only real registered Red Alert 3 objects.
objects=[];occupied=[]
def obj(typ,x,y,ang=0,owner=None,uid=None,roadflag=0):
 t=templates[typ];d=copy.deepcopy(t['props']);d['uniqueID']=(3,uid or f'Storm_{len(objects):05d}')
 d['objectLayer']=(3,'');d.pop('exportWithScript',None);d.pop('objectName',None)
 if owner is not None:d['originalOwner']=(3,owner)
 o=dict(ver=3,pos=(x*10,y*10,0.,ang,roadflag),type=typ,props=d);objects.append(o);return o
for i,(x,y) in enumerate(starts,1):
 o=obj('*Waypoints/Waypoint',x,y,uid=f'Player_{i}_Start',owner='/team');o['props']['waypointID']=(1,i);o['props']['waypointName']=(3,f'Player_{i}_Start');occupied.append((x,y,26))
# Capturable facilities and event plazas have dedicated clear, level approaches.
facilities=CFG['facilities'];supply_points=[]
for uid,typ,x,y,radius,title,effect in facilities:
 d=np.hypot(X-x,Y-y);t=np.clip((d-radius-3)/8,0,1);height=height*t+230*(1-t)
 o=obj(typ,x,y,math.pi/4,owner='SkirmishNeutral/teamSkirmishNeutral',uid=uid);o['props']['objectName']=(3,uid)
 occupied.append((x,y,radius+3))
for region,(sx,sy),crate_types in CFG['supplies']:
 for j,typ in enumerate(crate_types):
  x=sx+(j-1)*8;y=sy;name=f'SS_{region}_DROP_{j+1}'
  d=np.hypot(X-x,Y-y);t=np.clip((d-6)/5,0,1);height=height*t+230*(1-t)
  o=obj('*Waypoints/Waypoint',x,y,uid=name,owner='/team');o['props']['waypointID']=(1,20+len(supply_points));o['props']['waypointName']=(3,name)
  supply_points.append(dict(region=region,name=name,x=x,y=y,type=typ));occupied.append((x,y,8))
for sp in CFG['bonus_supply_points']:
 x,y=sp['x'],sp['y'];name='SS_'+sp['region']+'_DROP_1';d=np.hypot(X-x,Y-y);t=np.clip((d-6)/5,0,1);height=height*t+230*(1-t)
 o=obj('*Waypoints/Waypoint',x,y,uid=name,owner='/team');o['props']['waypointID']=(1,20+len(supply_points));o['props']['waypointName']=(3,name)
 supply_points.append(dict(region=sp['region'],name=name,x=x,y=y,type='RandomCache'));occupied.append((x,y,8))
# Dedicated coastal artillery platforms, reserved before resources and decoration.
for gi,gun in enumerate(CFG['coastal_guns']):
 x,y=gun['pad'];d=np.hypot(X-x,Y-y);t=np.clip((d-9)/5,0,1);height=height*t+230*(1-t);occupied.append((x,y,11))
 for wi,(kind,(x,y)) in enumerate([('PAD',gun['pad']),('AIM',gun['aim'])]):
  name=f"SS_GUN_{gun['region']}_{kind}";o=obj('*Waypoints/Waypoint',x,y,uid=name,owner='/team');o['props']['waypointID']=(1,40+gi*2+wi);o['props']['waypointName']=(3,name)
# Two home ore nodes per seat with a safe 150-unit refinery apron.
ore=[]
for i,(x,y) in enumerate(starts):
 for dx,dy,angle in [(-18,-18,3*math.pi/4),(18,18,7*math.pi/4)]:ore.append((x+dx,y+dy,angle,'home'))
# Coastal expansion sites make naval control economically useful.
for x,y in CFG['expansion']:ore.append((x,y,0.,'expansion'))
# Ore centers and facing must match the rotated building placement lattice.
ore_phases=phases_for_height(S)
ore=[(*snap(x,y,ang,ore_phases),kind) for x,y,ang,kind in ore]
# The official OreNode definition places the refinery hint 180 units along local +X.
# Score the four supported facings and reserve both footprints and the corridor.
refinery=[]
for oi,(x,y,ang,kind) in enumerate(ore):
 if kind in ('home','expansion'):
  scores=[]
  for candidate in DIAGONALS:
   nx,ny,aa=snap(x,y,candidate,ore_phases);rx=nx+18*math.cos(aa);ry=ny+18*math.sin(aa)
   mask=np.hypot(X-rx,Y-ry)<10
   penalty=float(np.mean(abs(height[mask]-230)))+float(np.mean(height[mask]<214))*300
   penalty+=sum(max(0,rr+9-math.hypot(rx-bx,ry-by))*1000 for bx,by,rr in occupied if all(math.hypot(bx-sx,by-sy)>1 for sx,sy in starts))
   penalty+=sum(max(0,24-math.hypot(rx-bx,ry-by))*1000 for jj,(bx,by,_,_) in enumerate(ore) if jj!=oi)
   penalty+=sum(max(0,19-math.hypot(rx-bx,ry-by))*1000 for bx,by in refinery)
   penalty+=sum(max(0,22-math.hypot(rx-bx,ry-by))*1000 for bx,by in starts)
   penalty+=sum(max(0,24-math.hypot(nx-bx,ny-by))*1000 for bx,by in refinery)
   if kind=='home':
    sx,sy=starts[oi//2]
    penalty+=max(0,math.hypot(rx-sx,ry-sy)-36)*1000
   penalty+=abs(math.atan2(math.sin(aa-ang),math.cos(aa-ang)))*.001
   scores.append((penalty,nx,ny,aa))
  _,x,y,ang=min(scores);ore[oi]=(x,y,ang,kind)
 rx=x+18*math.cos(ang);ry=y+18*math.sin(ang);refinery.append((rx,ry))
 for ax,ay,radius in [(x,y,8),(rx,ry,10),((x+rx)/2,(y+ry)/2,7)]:
  d=np.hypot(X-ax,Y-ay);t=np.clip((d-radius)/6,0,1);height=height*t+230*(1-t)
 obj('OreNode',x,y,ang,owner='SkirmishNeutral/teamSkirmishNeutral');occupied.extend([(x,y,11),(rx,ry,14),((x+rx)/2,(y+ry)/2,9)])
tech=[(139,439),(380,389),(307,693),(677,610),(707,424),(548,65)]
for tii,(x,y) in enumerate(tech):
 candidates=[]
 for radius in [0,8,16,24,32,40,48,56]:
  for k in range(16):
   tx=x+radius*math.cos(k*math.pi/8);ty=y+radius*math.sin(k*math.pi/8)
   if not (8<tx<S-8 and 8<ty<S-8):continue
   if not all(math.hypot(tx-a,ty-b)>r+8 for a,b,r in occupied):continue
   hz=height[int(ty+B),int(tx+B)]
   if hz<220 or hz>245:continue
   candidates.append((radius,tx,ty))
 assert candidates,('No clear oil site',tii)
 _,x,y=min(candidates);tech[tii]=(x,y)
 d=np.hypot(X-x,Y-y);t=np.clip((d-7)/6,0,1);height=height*t+230*(1-t)
 obj('OilDerrick',x,y,owner='SkirmishNeutral/teamSkirmishNeutral');occupied.append((x,y,10))
# Urban blocks have central traversable streets; no props on deployment pads.
def free(x,y,radius=0):return all(math.hypot(x-a,y-b)>r+radius for a,b,r in occupied)
def hval(x,y):return float(map_coordinates(height,[[y+B],[x+B]],order=1)[0])
buildings=['TH_BUILDING_01','TH_BUILDING_02','TH_Building_03','TH_Building_04','TH_Building_07','TH_Building_08']
for ci,(x,y,sx,sy) in enumerate(cities):
 for dx in [-sx*.56,sx*.56]:
  for dy in [-sy*.56,sy*.56]:
   px=x+dx;py=y+dy
   typ='TH_BUILDING_01' if min(sx,sy)<22 else buildings[(ci+int(dx>0)*2+int(dy>0))%len(buildings)]
   radius=6 if typ=='TH_BUILDING_01' else 11
   if not free(px,py,radius):continue
   obj(typ,px,py,0);occupied.append((px,py,radius))
 for dx in [-sx*.15,sx*.15]:
  for dy in np.arange(-sy+3,sy,8):
   if free(x+dx,y+dy,1):obj('TH_LAMPPOST04',x+dx,y+dy)
# Harbor cranes and container yards, with deliberately open dock entrances.
for k,(x,y,sx,sy) in enumerate(ports):
 for d in [-.55,.55]:
  if free(x+sx*.55,y+d*sy,8):obj('TH_harbor_crane01',x+sx*.55,y+d*sy,math.pi/4 if k%2 else -math.pi/4)
 for ix in range(3):
  for iy in range(4):
   px=x-sx*.7+ix*6;py=y-sy*.7+iy*8
   if free(px,py,1):obj(['TH_CARGOCONTAINER04','TH_CARGOCONTAINER05','TH_CARGOCONTAINER06'][(ix+iy)%3],px,py,0)
 occupied.append((x,y,max(sx,sy)+2))
# Native roads: paired start/end descriptors, underlaid by a wider terrain path.
for x,y,sx,sy in cities:
 for ax,ay,bx,by in [(x-sx,y,x+sx,y),(x-sx*.5,y-sy,x-sx*.5,y+sy),(x+sx*.5,y-sy,x+sx*.5,y+sy)]:
  obj('TokyoHarborSidewalk01',ax,ay,owner='/team',roadflag=2);obj('TokyoHarborSidewalk01',bx,by,owner='/team',roadflag=4)
# Groves, rocks and shoreline shrubs follow actual height/slope masks.
count=0
for _ in range(32000):
 x=random.uniform(5,S-5);y=random.uniform(5,S-5);xx=int(x+B);yy=int(y+B)
 if not free(x,y,1) or roadmask[yy,xx] or height[yy,xx]<219 or urbanmask[yy,xx]:continue
 if count>=2400:break
 if ridge[yy,xx]>25:
  if random.random()<.58:continue
  typ=random.choice(['YU_LARGEROCKS01','YU_LARGEROCKS02','YU_SMALLROCKS01','AP_MIRAGEROCK01'])
 else:typ=random.choice(['HB_Tree03','HB_Tree04','OK_Tree01','OK_Tree02','CC_BUSH02','OK_Shrub01'])
 obj(typ,x,y,random.uniform(-math.pi,math.pi));count+=1
for x,y in [(179,450),(368,265),(479,525),(721,408),(637,149),(322,702)]:
 if hval(x,y)>205:obj('CC_Lighthouse01',x,y)
for x,y in [(334,529),(552,283),(370,93)]:obj('YU_SUNKENSHIP03',x,y,.4)
for x,y in [(176,379),(353,386),(591,360)]:obj('Amb_WaterDockLoop',x,y)
for x,y in [(109,318),(414,505),(642,697)]:obj('Amb_CitySkyline',x,y)
# Texture and walkability update after resource flattening.
m.get('HeightMapData')[2]=h[:36]+np.rint(height/.0390625).clip(0,65535).astype('<u2').tobytes()
# Clear native impassability where aprons were flattened.
for x,y,ang,kind in ore:impass[np.hypot(X-x,Y-y)<14]=False
for x,y in refinery:impass[np.hypot(X-x,Y-y)<14]=False
for x,y in tech:impass[np.hypot(X-x,Y-y)<10]=False
for _,_,x,y,rr,_,_ in facilities:impass[np.hypot(X-x,Y-y)<rr+6]=False
for gun in CFG['coastal_guns']:
 x,y=gun['pad'];impass[np.hypot(X-x,Y-y)<10]=False
for sp in supply_points:impass[np.hypot(X-sp['x'],Y-sp['y'])<10]=False
bd=bytearray(m.get('BlendTileData')[2]);p=4+a*8;bd[p:p+bitbytes]=np.packbits(impass,axis=1,bitorder='little').tobytes();m.get('BlendTileData')[2]=bytes(bd)
m.get('ObjectsList')[2]=b''.join(m.obj_write(o) for o in objects)
# Union official asset dependency IDs so new Tokyo art can resolve.
assets=set()
for source in [m,tok,extra,brighton]:
 r=R(source.get('AssetList')[2]);n=r.u('I')
 for _ in range(n):assets.add(r.n(8))
m.get('AssetList')[2]=P('I',len(assets))+b''.join(sorted(assets))
# Loose custom maps need diffuse/normal asset pairs; compiled official maps do not
# carry this property. Preserve palette order, including materials not painted.
terrain_assets={e.attrib['id']:e.attrib for e in ET.parse('work/terrain-assets/Terrain.xml').getroot().iter() if e.tag.split('}')[-1]=='TerrainAsset'}
runtime_textures=[]
for _,material in textures:
 asset=terrain_assets[material]
 runtime_textures.extend(pathlib.PurePosixPath(asset[k]).stem for k in ['Texture','BumpTexture'])
world=m.props(m.get('WorldInfo')[2])
world['terrainTextureStrings']=(3,';'.join(runtime_textures)+';')
world['mapName']=(3,'Strait Storm - Wild Supplies [6P]')
world['mapDescription']=(3,'760x760. Random supply sites, intervals and loot. Hold an observation post for 120s to earn coastal artillery. v1.2')
world['compression']=(1,0);world['cameraGroundMinHeight']=(2,180.);world['cameraGroundMaxHeight']=(2,650.);world['isScenarioMultiplayer']=(0,0);m.get('WorldInfo')[2]=m.props_write(world)
# Afternoon with physically legible soft warm light; no custom shader requirement.
lb=bytearray(m.get('GlobalLighting')[2]);struct.pack_into('<I',lb,0,2);m.get('GlobalLighting')[2]=bytes(lb)
from areas import install_areas
install_areas(m,supply_points)
from events import install_events
script_report,event_strings=install_events(m,CFG)
name=OUT.name;m.write(OUT/(name+'.map'))
(OUT/'map.str').write_text(event_strings,encoding='utf-8-sig')
# Audit exports reference the exact heightfield and object placements written above.
np.savez_compressed('work/strait_storm/terrain.npz',height=height,regions=regions,types=typegrid,roadmask=roadmask,urbanmask=urbanmask,portmask=portmask,impass=impass)
pathlib.Path('work/strait_storm/scene.json').write_text(json.dumps(dict(starts=starts,objects=objects,polys=polys,cities=cities,ports=ports,ore=ore,refinery=refinery,tech=tech,facilities=facilities,coastal_guns=CFG['coastal_guns'],supply_points=supply_points,scripts=script_report),ensure_ascii=False,default=lambda x:x.item() if hasattr(x,"item") else str(x)))
print('BUILD OK',len(objects),'objects',len(ore),'ore',len(tech),'tech',len(desc),'blends',OUT)
# Structural round trip and spawn checks.
check=Map(OUT/(name+'.map'));assert len(check.objects())==len(objects);assert len({o['props']['uniqueID'][1] for o in objects})==len(objects)
for i,(x,y) in enumerate(starts):
 assert abs(hval(x,y)-230)<.05
 assert not impass[int(y+B),int(x+B)]
 assert len([o for o in objects if o['type']=='OreNode' and math.hypot(o['pos'][0]/10-x,o['pos'][1]/10-y)<29])>=2
check.write('work/strait_storm/roundtrip.map');assert pathlib.Path('work/strait_storm/roundtrip.map').read_bytes()==(OUT/(name+'.map')).read_bytes()
print('STRUCTURAL ROUNDTRIP + 6 SPAWN APRONS PASSED')
