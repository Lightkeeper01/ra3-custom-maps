"""RA3 rectangular supply trigger areas, matching the native TriggerAreas layout."""
from scriptio import Map,R,P,string

def parse(data):
 r=R(data);out=[]
 for _ in range(r.u('I')):
  name=r.s();layer=r.s();uid=r.u('I');points=[(r.u('f'),r.u('f')) for _ in range(r.u('I'))];assert r.u('I')==0
  out.append(dict(name=name,layer=layer,id=uid,points=points))
 assert r.p==len(data);return out

def wire(areas):
 b=P('I',len(areas))
 for a in areas:
  b+=string(a['name'])+string(a['layer'])+P('II',a['id'],len(a['points']))+b''.join(P('2f',*p) for p in a['points'])+P('I',0)
 return b

def install_areas(m,points):
 ref=Map('work/tokyo.map').get('TriggerAreas')[2];assert wire(parse(ref))==ref
 areas=[]
 for i,sp in enumerate(points,1):
  x,y=sp['x']*10,sp['y']*10;d=85
  areas.append(dict(name='SS_LOOT_AREA_'+str(i),layer='',id=100+i,points=[(x-d,y-d),(x+d,y-d),(x+d,y+d),(x-d,y+d)]))
 m.get('TriggerAreas')[2]=wire(areas);assert parse(wire(areas))==areas
