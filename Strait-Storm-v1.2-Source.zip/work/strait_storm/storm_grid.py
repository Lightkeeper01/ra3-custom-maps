import math, sys, pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from ore_grid import snap, DIAGONALS

def phases_for_height(playable_height):
    # Verified against all ore nodes in EA's 600x600 Carville and 500x450 Tokyo.
    # Terrain Y extent changes the origin of RA3's 45-degree building lattice.
    v=playable_height*10/math.sqrt(2)
    return [(0.,v+15.),(15.,v)]
