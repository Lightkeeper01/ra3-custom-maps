"""Interpret final serialized native scripts; checks do not replace RA3 runtime QA."""
import pathlib,json,random,math,xml.etree.ElementTree as ET
from scriptio import Map,read_tree,write_tree,walk
from areas import parse
from storm_grid import phases_for_height
W=pathlib.Path('work/strait_storm');path=pathlib.Path('outputs/海峡风暴_群岛争锋/Strait_Storm_6P/Strait_Storm_6P.map');m=Map(path);tree=read_tree(m,m.get('PlayerScriptsList'));scripts=tree['children'][0]['children'];cat=json.loads((W/'reference/script-catalog.json').read_text());areas=parse(m.get('TriggerAreas')[2]);objs=m.objects()
assert len(areas)==15 and len(tree['children'])==17
assert write_tree(m,tree)==m.chunk(m.get('PlayerScriptsList'))
assert len({s['strings'][0] for s in scripts})==len(scripts)
wp={o['props']['waypointName'][1] for o in objs if 'waypointName' in o['props']};area_names={a['name'] for a in areas}
localized=(path.parent/'map.str').read_text(encoding='utf-8-sig');assert '\0' not in localized
for n in walk(tree):
 if 'key' not in n:continue
 ref=cat[n['key']];assert (n['opcode'],n['ver'],n['keytype'])==(ref['opcode'],ref['ver'],ref['keytype']);assert [a[0] for a in n['args']]==[a[0] for a in ref['args']]
 assert n['key']!='DISPLAY_COUNTDOWN_TIMER'
 for a in n['args']:
  if a[0]==7:assert a[3] in wp
  if a[0]==9:assert a[3] in area_names
  if a[0]==15:assert a[3]==a[3].lower()
 if n['key']=='SHOW_MILITARY_CAPTION':assert n['args'][0][3] in localized and n['args'][1][2]==4.
count=0
for p,height in [('work/base.map',600),('work/tokyo.map',450)]:
 for o in Map(p).objects():
  if o['type']!='OreNode':continue
  x,y,_,angle,_=o['pos'];phase=phases_for_height(height)[round((angle-math.pi/4)/(math.pi/2))%2]
  assert max(abs((a-b+15)%30-15) for a,b in zip(((x+y)/math.sqrt(2),(y-x)/math.sqrt(2)),phase))<.003;count+=1
weapon=next(e for e in ET.parse(W/'reference/BB_EuropeCoastalGun.xml').getroot().iter() if e.attrib.get('id')=='BB_EuropeCoastalGunWeapon')
assert weapon.attrib['AttackRange']=='2000.0' and 'ANTI_WATER' in weapon.attrib['RequiredAntiMask']

def run(seed,duration=1800,pickup='normal',held=1,force=None):
 rng=random.Random(seed);counters={};timers={};flags={};named={};off=set();reveals=set();captions=[];cash=[];units=[];drops=[];wins=[];guns=[];arrival=-999;site_seen=set();loot_seen=set();priority=1
 def S(n,i):return n['args'][i][3]
 def I(n,i):return n['args'][i][1]
 def F(n,i):return n['args'][i][2]
 def beacon_owner(t):
  if held=='handover':return 1 if t<110 else (0 if t<140 else 2)
  if held=='destroyed':return 1 if t<100 else 0
  return held
 def players_at(t):
  if t-arrival<5:return set()
  if pickup in ['absent','destroyed']:return set()
  if pickup=='tie':return set(range(1,7))
  return {seed%6+1}
 def cond(n,t):
  k=n['key'];v=False
  if k=='CONDITION_TRUE':v=True
  elif k=='COUNTER':
   a,b=counters.get(S(n,0),0),I(n,2);v=[a<b,a<=b,a==b,a>=b,a>b,a!=b][I(n,1)]
  elif k=='TIMER_EXPIRED':v=t>=timers.get(S(n,0),float('inf'))
  elif k=='FLAG':v=flags.get(S(n,0),False)==bool(I(n,1))
  elif k=='NAMED_NOT_DESTROYED':v=S(n,0) in named or (S(n,0).endswith('_BEACON') and not(held=='destroyed' and t>=100))
  elif k=='NAMED_OWNED_BY_PLAYER':v=beacon_owner(t)>0 and S(n,0)=='Player_'+str(beacon_owner(t))
  elif k=='SKIRMISH_PLAYER_HAS_UNITS_IN_AREA':v=S(n,1)=='SS_LOOT_AREA_'+str(counters.get('SS_SITE',0)) and int(S(n,0).split('_')[1]) in players_at(t)
  else:raise AssertionError(k)
  return not v if n.get('invert') else v
 for t in range(duration+1):
  if pickup=='destroyed' and t-arrival>=3:named.pop('SS_DROP_MARKER',None)
  for ix,script in enumerate(scripts):
   if ix in off or not all(cond(n,t) for n in script['children'][0]['children']):continue
   if script['flags'][1]:off.add(ix)
   if script['strings'][0].startswith('SS_AWARD_'):
    assert counters['SS_PHASE']==4
    winner=counters['SS_WINNER'];wins.append((t,winner,counters['SS_LOOT']))
    assert t-arrival<90 and winner in players_at(t)
    if pickup=='tie':assert winner==counters['SS_PRIORITY']
   for n in script['children'][1:]:
    k=n['key']
    if k=='SET_COUNTER':counters[S(n,0)]=I(n,1)
    elif k=='SET_FLAG':flags[S(n,0)]=bool(I(n,1))
    elif k=='SET_TIMER':timers[S(n,0)]=t+I(n,1)
    elif k=='SET_RANDOM_MSEC_TIMER':
     value=rng.uniform(F(n,1),F(n,2));assert 90<=value<=210;timers[S(n,0)]=t+value
    elif k=='SET_RANDOM_COUNTER':
     value=rng.randint(I(n,1),I(n,2))
     if force and S(n,0) in force:value=force[S(n,0)]
     counters[S(n,0)]=value
    elif k in ['CREATE_NAMED_ON_TEAM_AT_WAYPOINT','CREATE_NAMED_ON_TEAM_AT_WAYPOINT_WITH_ORIENTATION']:
     uid=S(n,0);assert uid not in named;named[uid]=S(n,1)
     if uid=='SS_DROP_MARKER':
      arrival=t;drops.append((t,counters['SS_SITE'],counters['SS_LOOT']));site_seen.add(counters['SS_SITE']);loot_seen.add(counters['SS_LOOT'])
     else:
      assert uid.startswith('SS_COASTAL_GUN_');guns.append((t,uid,S(n,2)));assert S(n,2)==f'Player_{beacon_owner(t)}/teamPlayer_{beacon_owner(t)}'
      assert t>=(260 if held=='handover' else 120)
    elif k=='CREATE_UNNAMED_ON_TEAM_AT_WAYPOINT':
     assert 'SS_DROP_MARKER' not in named,'Spawn space blocked by cache'
     units.append((t,S(n,0),S(n,1)))
    elif k=='PLAYER_GIVE_MONEY':cash.append((t,S(n,0),I(n,1)));assert I(n,1) in [1500,3000]
    elif k=='NAMED_DELETE':assert S(n,0) in named;del named[S(n,0)]
    elif k=='MAP_REVEAL_PERMANENTLY_AT_WAYPOINT':assert S(n,3) not in reveals;reveals.add(S(n,3))
    elif k=='MAP_UNDO_REVEAL_PERMANENTLY_AT_WAYPOINT':reveals.remove(S(n,0))
    elif k=='SHOW_MILITARY_CAPTION':captions.append((t,F(n,1)))
    elif k=='NAMED_FORCE_ATTACK_WAYPOINT':assert S(n,0) in named and S(n,1).endswith('_AIM')
    elif k in ['HIDE_COUNTER','NAMED_FLASH','OBJECT_CREATE_RADAR_EVENT']:pass
    else:raise AssertionError(k)
  assert len([k for k in named if k=='SS_DROP_MARKER'])<=1
  assert len(guns)<=3 and len(reveals)<=1
 assert len({t for t,_,_ in wins})==len(wins),'Duplicate claim'
 assert all(b[0]-a[0]>=8 for a,b in zip(captions,captions[1:])), 'Caption spam/overlap'
 if pickup in ['absent','destroyed']:assert not wins and not cash and not units
 if held in [0,'destroyed']:assert not guns
 else:assert len(guns)==3
 return dict(events=len(drops),awards=len(wins),cash_awards=len(cash),units=len(units),guns=len(guns),sites=sorted(site_seen),loot=sorted(loot_seen),gun_times=[g[0] for g in guns])
results={}
for seed in range(1,7):results['seed_'+str(seed)]=run(seed,duration=3600,held=seed)
for mode in ['absent','destroyed','tie']:results[mode]=run(19,pickup=mode)
results['interrupted_challenge']=run(5,held='handover');results['destroyed_beacons']=run(6,held='destroyed');results['neutral_beacons']=run(7,held=0)
for loot in range(1,7):results['forced_reward_'+str(loot)]=run(loot,duration=450,force={'SS_SITE':15,'SS_LOOT':loot},held=0)
assert set.union(*(set(v['sites']) for v in results.values()))==set(range(1,16))
assert set.union(*(set(v['loot']) for v in results.values()))==set(range(1,7))
report=dict(status='PASS',script_count=len(scripts),scenarios=results,official_grid_nodes=count,trigger_areas=len(areas),coastal_gun_range=2000,anti_water=True,persistent_timer_panel=False,caption_seconds=4,limitation='Native script model, not engine QA; random scripts are native, simulation uses seeded stand-in RNG.')
(W/'event-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
