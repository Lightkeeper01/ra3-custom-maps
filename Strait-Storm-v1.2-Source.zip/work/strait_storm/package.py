import pathlib,json,hashlib,zipfile,shutil
R=pathlib.Path('.');W=R/'work/strait_storm';D=R/'outputs/海峡风暴_群岛争锋';N='Strait_Storm_6P'
(D/'玩法与安装说明.md').write_text((W/'guide.md').read_text())
for src,dst in [('work/EA_LICENSE.md','LICENSE-EA.md'),('work/OpenSAGE/LICENSE.md','LICENSE-OpenSAGE.md'),('work/OpenSAGE/LICENSE-EA.md','LICENSE-OpenSAGE-EA.md')]:shutil.copy2(src,D/dst)
ps=r'''$ErrorActionPreference = 'Stop'
$mapName = 'Strait_Storm_6P'
$source = Join-Path $PSScriptRoot $mapName
$mapsRoot = Join-Path $env:APPDATA 'Red Alert 3\Maps'
$destination = Join-Path $mapsRoot $mapName
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Map-Checksums.json') -Raw | ConvertFrom-Json
foreach ($entry in $manifest.PSObject.Properties) {
 $file = Join-Path $source $entry.Name
 if (-not (Test-Path -LiteralPath $file)) { throw ('Missing file: '+$entry.Name+'. Extract the whole ZIP first.') }
 if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.Value) { throw ('Checksum mismatch: '+$entry.Name) }
}
New-Item -ItemType Directory -Path $mapsRoot -Force | Out-Null
if (Test-Path -LiteralPath $destination) {
 $backupRoot = Join-Path $env:APPDATA 'Red Alert 3\CodexMapBackups'
 New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
 $backup = Join-Path $backupRoot ($mapName+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
 Copy-Item -LiteralPath $destination -Destination $backup -Recurse
 Write-Output ('Previous event map backed up: '+$backup)
}
New-Item -ItemType Directory -Path $destination -Force | Out-Null
Get-ChildItem -LiteralPath $source -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $destination -Force }
foreach ($entry in $manifest.PSObject.Properties) {
 if ((Get-FileHash -LiteralPath (Join-Path $destination $entry.Name) -Algorithm SHA256).Hash -ne $entry.Value) { throw ('Installed checksum mismatch: '+$entry.Name) }
}
Write-Output ('Map installed: '+$destination)
Write-Output 'v1.2 random supplies + coastal gun challenge TEST BUILD. Restart RA3 and choose Strait Storm - Wild Supplies [6P].'
'''
(D/'Install-Map.ps1').write_text(ps,encoding='utf-8-sig')
(D/'Install-Map.cmd').write_bytes(b'@echo off\r\ncd /d "%~dp0"\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Map.ps1"\r\nif errorlevel 1 (echo Installation failed.) else (echo Installation completed.)\r\npause\r\n')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((D/N).iterdir()) if p.is_file()};(D/'Map-Checksums.json').write_text(json.dumps(manifest,indent=2))
v=json.loads((W/'validation.json').read_text());assert not v['issues'];v['events']=json.loads((W/'event-validation.json').read_text());assert v['events']['status']=='PASS';v['map_sha256']=manifest[N+'.map']
for file in ['installation.json','source-validation.json']:
 if (W/file).exists():
  rec=json.loads((W/file).read_text())
  if rec.get('sha256')==v['map_sha256']:v[file[:-5]]=rec
(D/'验证记录.json').write_text(json.dumps(v,ensure_ascii=False,indent=2))
with zipfile.ZipFile(R/'outputs/海峡风暴_随机补给与岸防炮_v1.2测试版.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(D.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(D))
source=[pathlib.Path(p) for p in ['work/EA_LICENSE.md','work/OpenSAGE/LICENSE.md','work/OpenSAGE/LICENSE-EA.md','work/mapio.py','work/ore_grid.py','work/base.map','work/tokyo.map','work/terrain-assets/Terrain.xml']]
source+=list(pathlib.Path('work/geometry').glob('*.xml'))
source += [W/p for p in ['build.py','design.json','events.py','areas.py','scriptio.py','storm_grid.py','validate.py','test_events.py','preview.py','package.py','guide.md']]
source += [W/'reference'/p for p in ['script-catalog.json','CAMP_S04_Geneva_Bass.map','CAMP_A01_BrightonBeach_Smith.map','BB_EuropeCoastalGun.xml']]
with zipfile.ZipFile(R/'outputs/海峡风暴_随机事件制作源包_v1.2.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in source:z.write(p,p)
 for p in D.glob('LICENSE*'):z.write(p,p.name)
 z.writestr('README.md',(W/'guide.md').read_text())
print('v1.2 packages written; map SHA256',v['map_sha256'])
