import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mapio import *
import numpy as np,json,pathlib,math,xml.etree.ElementTree as ET
from scipy.ndimage import label,binary_erosion,distance_transform_edt
path=pathlib.Path('outputs/海峡风暴_群岛争锋/Strait_Storm_6P/Strait_Storm_6P.map');m=Map(path);objs=m.objects();sc=json.load(open('work/strait_storm/scene.json'))
r=R(m.get('HeightMapData')[2]);w=r.u('I');hh=r.u('I');b=r.u('I');n=r.u('I');r.n(n*16);area=r.u('I');h=np.frombuffer(r.n(area*2),'<u2').reshape(hh,w)*.0390625;assert r.p==len(r.b)
starts=[o for o in objs if o['type']=='*Waypoints/Waypoint' and o['props'].get('waypointName',(3,''))[1].startswith('Player_')];assert len(starts)==6;assert {o['props']['waypointName'][1] for o in starts}=={f'Player_{i}_Start' for i in range(1,7)}
assert sum(o['type']=='OreNode' for o in objs)==34
assert sum(o['type']=='OilDerrick' for o in objs)==6
# Compare directly against official object centers, independently of snap().
# Same map extent is essential: the rotated lattice has an extent-based origin.
reference=Map('work/base.map')
assert (w,hh,b)==(820,820,30)
reference_nodes=[o for o in reference.objects() if o['type']=='OreNode']
grid_errors=[]
for o in [o for o in objs if o['type']=='OreNode']:
 x,y,_,angle,_=o['pos']
 assert abs(math.cos(4*angle)+1)<1e-8, 'Ore facing is not on the 45-degree building grid'
 peers=[r for r in reference_nodes if abs(math.sin(r['pos'][3]-angle))<1e-5]
 assert peers
 rx,ry=peers[0]['pos'][:2]
 deltas=[((x+y)-(rx+ry))/math.sqrt(2),((y-x)-(ry-rx)-(760-600)*10)/math.sqrt(2)]
 error=max(abs((d+15)%30-15) for d in deltas)
 assert error<.003, 'Ore center is off the official building placement grid'
 grid_errors.append(error)
r=R(m.get('BlendTileData')[2]);assert r.u('I')==area;r.n(area*8);bits=((w+7)//8)*hh;impass=np.unpackbits(np.frombuffer(r.n(bits),np.uint8).reshape(hh,-1),axis=1,bitorder='little')[:,:w].astype(bool)
# Regress the real black-terrain failure: loose maps must resolve every palette
# material through EA's diffuse/normal names in exactly the serialized order.
r.n(bits*7+area);r.n(12);nt=r.u('I');palette=[]
for _ in range(nt):r.n(16);palette.append(r.s())
assets={e.attrib['id']:e.attrib for e in ET.parse('work/terrain-assets/Terrain.xml').getroot().iter() if e.tag.split('}')[-1]=='TerrainAsset'}
expected=[pathlib.PurePosixPath(assets[name][k]).stem for name in palette for k in ['Texture','BumpTexture']]
world=m.props(m.get('WorldInfo')[2])
assert world.get('terrainTextureStrings')==(3,';'.join(expected)+';'), 'Missing or incorrect runtime terrain texture mapping'
assert world['mapName']==(3,'Strait Storm - Wild Supplies [6P]')
land=(h>201)&~impass;land_ids,_=label(land)
sea=(h<198)&~impass;sea_ids,sea_n=label(sea)
# Sampling grid and logical connectivity only; actual engine pathing remains a runtime check.
Y,X=np.mgrid[-b:hh-b,-b:w-b]
issues=[];summary=[]
for i,(x,y) in enumerate(sc['starts'],1):
 idx=land_ids[round(y+b),round(x+b)];assert idx>0
 home=sc['ore'][(i-1)*2:i*2];row=dict(seat=i,land_component=int(idx),spawn_height=float(h[round(y+b),round(x+b)]))
 for ox,oy,angle,kind in home:
  assert land_ids[round(oy+b),round(ox+b)]==idx
  rx=ox+18*math.cos(angle);ry=oy+18*math.sin(angle)
  mask=np.hypot(X-rx,Y-ry)<8
  hs=h[mask]
  if hs.max()-hs.min()>.12:issues.append(f'seat {i} refinery apron uneven {hs.min():.2f}-{hs.max():.2f}')
 row['home_ore_reachable']=True;summary.append(row)
# Refineries: all native 180-unit hint positions are on level, clear land.
for i,((ox,oy,ang,kind),(rx,ry)) in enumerate(zip(sc['ore'],sc['refinery']),1):
 assert abs(ox+18*math.cos(ang)-rx)<1e-4
 mask=np.hypot(X-rx,Y-ry)<8;hs=h[mask]
 if hs.min()<220:issues.append(f'ore {i} refinery low or underwater')
 if hs.max()-hs.min()>.12:issues.append(f'ore {i} refinery apron uneven {hs.min():.2f}-{hs.max():.2f}')
# Simultaneous refinery build footprints must not overlap nearby nodes or each other.
for i,a in enumerate(sc['ore']):
 for j,bb in enumerate(sc['ore'][i+1:],i+1):
  if math.dist(a[:2],bb[:2])<28:issues.append(f'ore spacing {i+1}/{j+1}')
for i,a in enumerate(sc['refinery']):
 for j,bb in enumerate(sc['ore']):
  if i!=j and math.dist(a,bb[:2])<22:issues.append(f'refinery {i+1} conflicts with ore {j+1}')
 for j,bb in enumerate(sc['refinery'][i+1:],i+1):
  if math.dist(a,bb)<18:issues.append(f'refineries {i+1}/{j+1} overlap')
# Primary decorative building bounding shapes from EA XML, used conservatively.
geom={}
for p in pathlib.Path('work/geometry').glob('*.xml'):
 root=ET.parse(p).getroot();shapes=[e for e in root.iter() if e.tag.split('}')[-1]=='Shape']
 boxes=[]
 for sh in shapes:
  a=sh.attrib
  if 'MajorRadius' not in a:continue
  off=next((e for e in sh if e.tag.split('}')[-1]=='Offset'),None);ox=float(off.attrib.get('x',0)) if off is not None else 0;oy=float(off.attrib.get('y',0)) if off is not None else 0
  rx=float(a['MajorRadius']);ry=float(a.get('MinorRadius',rx));boxes.append((ox-rx,oy-ry,ox+rx,oy+ry))
 if boxes:geom[p.stem.lower()]=(min(z[0] for z in boxes),min(z[1] for z in boxes),max(z[2] for z in boxes),max(z[3] for z in boxes))
structs=[]
for o in objs:
 if 'building_' not in o['type'].lower():continue
 bb=geom.get(o['type'].lower())
 if bb is None:continue
 x,y,z,ang,flag=o['pos'];co,si=math.cos(ang),math.sin(ang);pts=[(x+px*co-py*si,y+px*si+py*co) for px in [bb[0],bb[2]] for py in [bb[1],bb[3]]]
 box=(min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts));structs.append((o['props']['uniqueID'][1],box))
for i,(na,a) in enumerate(structs):
 for nb,bb in structs[i+1:]:
  if min(a[2],bb[2])-max(a[0],bb[0])>1 and min(a[3],bb[3])-max(a[1],bb[1])>1:issues.append(f'overlapping buildings {na} {nb}')
# Facility capture paths and event pickup pads must stay clear of ore/refineries.
for uid,typ,fx,fy,radius,title,effect in sc['facilities']:
 for i,(ox,oy,ang,kind) in enumerate(sc['ore']):
  if math.hypot(ox-fx,oy-fy)<radius+8:issues.append(f'facility {uid} overlaps ore {i+1}')
 for i,(rx,ry) in enumerate(sc['refinery']):
  if math.hypot(rx-fx,ry-fy)<radius+8:issues.append(f'facility {uid} overlaps refinery {i+1}')
for sp in sc['supply_points']:
 for i,(ox,oy,ang,kind) in enumerate(sc['ore']):
  if math.hypot(ox-sp['x'],oy-sp['y'])<12:issues.append(f'supply {sp["name"]} overlaps ore {i+1}')
 for i,(rx,ry) in enumerate(sc['refinery']):
  if math.hypot(rx-sp['x'],ry-sp['y'])<14:issues.append(f'supply {sp["name"]} overlaps refinery {i+1}')
for gun in sc['coastal_guns']:
 x,y=gun['pad'];ax,ay=gun['aim'];mask=np.hypot(X-x,Y-y)<4;hs=h[mask]
 if hs.min()<225 or hs.max()-hs.min()>.12:issues.append('uneven coastal gun platform '+gun['region'])
 if h[round(ay+b),round(ax+b)]>=198:issues.append('coastal gun aim is not sea '+gun['region'])
 if not 100<math.dist([x,y],[ax,ay])*10<2000:issues.append('coastal gun range '+gun['region'])
 for i,ore in enumerate(sc['ore']):
  if math.dist([x,y],ore[:2])<14:issues.append(f'gun {gun["region"]} overlaps ore {i+1}')
 for i,rf in enumerate(sc['refinery']):
  if math.dist([x,y],rf)<14:issues.append(f'gun {gun["region"]} overlaps refinery {i+1}')
# Verify palette IDs, chunk sizes and rebuild identity.
m.write('work/strait_storm/validated-roundtrip.map');assert path.read_bytes()==pathlib.Path('work/strait_storm/validated-roundtrip.map').read_bytes()
rep=dict(status='NEW_EVENT_MAP_RUNTIME_UNVERIFIED',version='1.2-test',ore_grid_max_error_game_units=max(grid_errors),runtime_texture_pairs=nt,size=[760,760],objects=len(objs),seats=summary,ore_nodes=34,oil_derricks=6,building_footprints_checked=len(structs),sea_components=int(sea_n),issues=issues,limitations=['New map dimensions, special facility art and event scripts require in-game testing. Old map remains separate.','Naval pathing, all three faction construction, AI behavior and match completion require RA3 runtime verification.','Geometric tests are not a guarantee of engine compatibility.'])
pathlib.Path('work/strait_storm/validation.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2));print(json.dumps(rep,ensure_ascii=False,indent=2));assert not issues
