import numpy as np,json,pathlib
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from scipy.ndimage import gaussian_filter
D=pathlib.Path('outputs/海峡风暴_群岛争锋');data=np.load('work/strait_storm/terrain.npz');sc=json.load(open('work/strait_storm/scene.json'));h=data['height'][30:790,30:790];reg=data['regions'][30:790,30:790];rd=data['roadmask'][30:790,30:790];um=data['urbanmask'][30:790,30:790];pm=data['portmask'][30:790,30:790]
gy,gx=np.gradient(h);light=np.clip((-.55*gx+.6*gy+4)/np.sqrt(gx*gx+gy*gy+16),.25,1.3)
# Terrain-derived preview, north up. Palette is cartographic, not a claimed game capture.
sea=np.array([16,66,83.]);shallow=np.array([40,132,137.]);sand=np.array([179,163,115.]);grass=np.array([66,97,65.]);mount=np.array([137,135,110.])
c=np.zeros((*h.shape,3))
t=np.clip((h-110)/90,0,1)[...,None];c[:]=sea*(1-t)+shallow*t
mask=h>200;t=np.clip((h-202)/23,0,1)[...,None];lc=sand*(1-t)+grass*t
mt=np.clip((h-250)/110,0,1)[...,None];lc=lc*(1-mt)+mount*mt;c[mask]=lc[mask]
c[rd]=[126,123,105];c[um|pm]=[137,147,142];c[mask]*=light[mask,None]*.52+.55
c=np.clip(c,0,255).astype('uint8');im=Image.fromarray(c[::-1]).resize((1200,1200),Image.Resampling.LANCZOS)
d=ImageDraw.Draw(im,'RGBA');
# Coastline contour from sea crossing.
shore=(h>200)&(h<205);coast=np.zeros((760,760,4),np.uint8);coast[shore]=[201,215,168,145];coast=Image.fromarray(coast[::-1]).resize(im.size);im=Image.alpha_composite(im.convert('RGBA'),coast);d=ImageDraw.Draw(im,'RGBA')
def available_font(paths):
 for p in paths:
  if pathlib.Path(p).exists():return p
 raise FileNotFoundError('Install an appropriate font and update preview.py font search paths.')
font=available_font(['/System/Library/Fonts/Supplemental/Arial.ttf','C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'])
f=lambda n:ImageFont.truetype(font,n)
for o in sc['objects']:
 x,y=o['pos'][0]*120/760,1200-o['pos'][1]*120/760;t=o['type']
 if t=='OreNode':d.polygon([(x,y-5),(x+5,y),(x,y+5),(x-5,y)],fill='#e4c27a')
 elif t=='OilDerrick':d.rectangle((x-4,y-4,x+4,y+4),fill='#dddad0')
 elif 'Building_' in t or 'BUILDING_' in t:d.rectangle((x-3,y-3,x+3,y+3),fill=(220,215,192,190))
colors=['#e44a40','#67c4b9','#edb45e','#b59cdb','#76acd9','#88b56a']
for i,(x,y) in enumerate(sc['starts']):
 x*=1200/760;y=1200-y*1200/760;d.ellipse((x-22,y-22,x+22,y+22),fill=(10,25,31,245),outline=colors[i],width=3);d.text((x,y-1),str(i+1),font=f(28),anchor='mm',fill='white')

for uid,typ,x,y,r,title,effect in sc['facilities']:
 x=x*1200/760;y=1200-y*1200/760
 d.rectangle((x-5,y-5,x+5,y+5),fill='#f4e7ba',outline='#20313b',width=1)
for sp in sc['supply_points']:
 x,y=sp['x']*1200/760,1200-sp['y']*1200/760
 d.ellipse((x-7,y-7,x+7,y+7),outline='#ffe2a1',width=2)
for gun in sc['coastal_guns']:
 x,y=gun['pad'][0]*1200/760,1200-gun['pad'][1]*1200/760
 d.polygon([(x-8,y-7),(x+10,y),(x-8,y+7)],fill='#ff927d',outline='#1a2631')
 d.line((x+10,y,x+42,y),fill='#ff927d',width=2)
name='Strait_Storm_6P'
mini=im.convert('RGB').resize((512,512),Image.Resampling.LANCZOS)
for suffix in ['_art.tga','_pic.tga']:mini.save(D/name/(name+suffix))
im.convert('RGB').save(D/'群岛争锋_地形小地图.png')
cf=available_font(['/System/Library/AssetsV2/com_apple_MobileAsset_Font7/3419f2a427639ad8c8e139149a287865a90fa17e.asset/AssetData/PingFang.ttc','/System/Library/Fonts/PingFang.ttc','C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'])
cn=lambda n:ImageFont.truetype(cf,n,index=0)
sheet=Image.new('RGB',(1920,1510),'#101e26');sheet.paste(im.convert('RGB'),(48,235));d=ImageDraw.Draw(sheet)
d.text((50,38),'STRAIT STORM  /  ARCHIPELAGO',font=f(25),fill='#c6b88f')
d.text((48,86),'海峡风暴：群岛争锋',font=cn(64),fill='#f1eadb')
d.text((52,178),'760 × 760  ·  随机补给 + 岸防挑战  ·  34 矿点  ·  8 特殊设施  ·  红警 3 原版',font=cn(23),fill='#a8b9c0')
d.line((1290,235,1290,1435),fill='#3a4950')
x=1332
d.text((x,238),'探索补给，争夺海岸控制权',font=cn(30),fill='#eee6d6')
rows=[('01 / 随机补给','#ecc980','15 个落点随机选择','15 秒预告 · 90 秒领取窗口','等待间隔与奖励均由原版脚本随机'),('02 / 钱、兵与军械','#77d3c8','1500 / 3000 资金，或动员兵小队','也可能获得天狗、激流、双刃','部队靠近补给仓后，奖励归领取方'),('03 / 海岸炮台挑战','#ffaa91','工程师占领观察哨','连续控制 120 秒；失去控制重置','完成后交付能攻击海面的原版岸防炮')]
for i,(title,col,a,b,c) in enumerate(rows):
 y=320+i*195;d.rounded_rectangle((x,y,x+530,y+165),radius=10,fill='#192c35');d.rectangle((x,y+12,x+4,y+153),fill=col)
 d.text((x+22,y+16),title,font=cn(27),fill=col)
 for j,t in enumerate([a,b,c]):d.text((x+22,y+60+j*31),t,font=cn(21),fill='#c0cbd0')
d.text((x,938),'金色圆点：随机落点   红色箭头：岸防炮',font=cn(23),fill='#eee6d6')
d.text((x,984),'每处炮台整局只奖励一次，摧毁不重刷。',font=cn(21),fill='#a8b9c0')
d.text((x,1022),'取消常驻计时框；短提示 4 秒后消失。',font=cn(21),fill='#a8b9c0')
d.line((x,1085,x+530,1085),fill='#3a4950')
d.text((x,1110),'起点编号 / 剧情席位',font=cn(25),fill='#eee6d6')
for i,t in enumerate(['1 中国大陆    2 台湾    3 日本','4 俄罗斯        5 美国    6 澳大利亚']):d.text((x,1160+i*38),t,font=cn(22),fill='#c0cbd0')
d.text((x,1270),'以标准遭遇战规则获胜；队伍自行设置。',font=cn(21),fill='#a8b9c0')
d.text((x,1310),'v1.2 随机事件测试版；旧海峡风云保留。',font=cn(21),fill='#a8b9c0')
d.text((x,1370),'架空剧本；地理为玩法压缩。',font=cn(19),fill='#7e949e')
d.text((50,1460),'由交付地图的真实地形数据绘制；这是战术总览，不是游戏实机截图。',font=cn(20),fill='#859da8')
sheet.save(D/'群岛争锋_战场总览.png')
print('Storm overview and native minimaps saved')
