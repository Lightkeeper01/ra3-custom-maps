"""Vanilla RA3 randomized salvage and continuous-control coastal-gun challenge."""
import json,copy,pathlib
from scriptio import read_tree,write_tree,walk
ROOT=pathlib.Path('work/strait_storm')
CAT=json.loads((ROOT/'reference/script-catalog.json').read_text())

def command(key,*values):
 o=copy.deepcopy(CAT[key]);assert len(values)==len(o['args']),(key,values)
 for a,v in zip(o['args'],values):
  if isinstance(v,str):a[3]=v.lower() if a[0]==15 else v
  elif isinstance(v,float):a[2]=v
  else:a[1]=int(v)
 o['enabled']=1
 if o['kind']=='Condition':o['invert']=0
 else:o['kind']='ScriptAction'
 return o

def script(name,conditions,actions,once=False):
 return dict(kind='Script',ver=4,strings=[name,'Authored vanilla event logic.','',''],flags=[1,int(once),1,1,1,0],interval=1,sequential=[0,0,0,1,''],unknown='X',children=[dict(kind='OrCondition',ver=1,children=conditions)]+actions)

def install_events(m,cfg):
 c=command;steps=[];strings={};messages={}
 def msg(key,text):
  if key not in messages:messages[key]=len(messages)+1;strings['MSN:STRAITSTORM12:'+key]=text
  return c('SET_COUNTER','SS_MESSAGE',messages[key])
 def eq(key,value):return c('COUNTER',key,2,value)
 def neq(key,value):return c('COUNTER',key,5,value)
 def flag(key,value):return c('FLAG',key,value)
 def exists(name):return c('NAMED_NOT_DESTROYED',name)
 def invert(cond):cond['invert']=1;return cond
 def owned(p,name):return c('NAMED_OWNED_BY_PLAYER',f'Player_{p}',name)
 def team(p):return f'Player_{p}/teamPlayer_{p}'
 labels={'NORTH':'北部训练岛','WEST':'西部维修港','SOUTH':'南部救援岛','COAST':'西岸前哨','TAIWAN':'本岛南部','JAPAN':'东北外围岛','RUSSIA':'西北外围岛','USA':'东部外围岛','AUSTRALIA':'南部外围岛'}
 sites=[]
 for region,(x,y),_ in cfg['supplies']:
  for i in range(1,4):sites.append((region,f'SS_{region}_DROP_{i}'))
 for sp in cfg['bonus_supply_points']:sites.append((sp['region'],'SS_'+sp['region']+'_DROP_1'))
 # All randomness uses native synchronized script actions, not wall time or Python RNG.
 actions=[c('SET_COUNTER','SS_PHASE',0),c('SET_COUNTER','SS_MESSAGE',0),c('SET_COUNTER','SS_WINNER',0),c('HIDE_COUNTER','SS_EVENT'),c('SET_RANDOM_MSEC_TIMER','SS_EVENT',90.,180.),c('SET_TIMER','SS_NOTICE_COOLDOWN',0),c('SET_TIMER','SS_INTRO',3)]
 for gun in cfg['coastal_guns']:
  r=gun['region'];actions += [c('SET_FLAG','SS_GUN_DONE_'+r,False),c('SET_COUNTER','SS_HOLD_OWNER_'+r,0)]
 steps.append(script('SS_INIT',[c('CONDITION_TRUE')],actions,True))
 steps.append(script('SS_INTRO',[c('TIMER_EXPIRED','SS_INTRO')],[msg('INTRO','补给随机出现。部队靠近领取；占领观察哨守住120秒可获岸防炮。')],True))
 steps.append(script('SS_ROLL',[eq('SS_PHASE',0),c('TIMER_EXPIRED','SS_EVENT')],[c('SET_RANDOM_COUNTER','SS_SITE',1,len(sites)),c('SET_RANDOM_COUNTER','SS_LOOT',1,6),c('SET_RANDOM_COUNTER','SS_PRIORITY',1,6),c('SET_COUNTER','SS_WINNER',0),c('SET_COUNTER','SS_PHASE',1)]))
 for si,(region,wp) in enumerate(sites,1):
  steps.append(script(f'SS_WARN_{si}',[eq('SS_PHASE',1),eq('SS_SITE',si)],[msg('WARN_'+region,labels[region]+'：15秒后发现补给，请查看小地图。'),c('MAP_REVEAL_PERMANENTLY_AT_WAYPOINT',wp,30.,'<All Players>','SS_DROP_REVEAL'),c('SET_COUNTER','SS_PHASE',2),c('SET_TIMER','SS_EVENT',15)]))
  steps.append(script(f'SS_ARRIVE_{si}',[eq('SS_PHASE',2),eq('SS_SITE',si),c('TIMER_EXPIRED','SS_EVENT')],[c('CREATE_NAMED_ON_TEAM_AT_WAYPOINT','SS_DROP_MARKER','TH_JapanCrate01','SkirmishNeutral/teamSkirmishNeutral',wp),c('NAMED_FLASH','SS_DROP_MARKER',20),c('OBJECT_CREATE_RADAR_EVENT','SS_DROP_MARKER',0),msg('ARRIVE_'+region,labels[region]+'：补给仓已出现！90秒内派部队靠近领取。'),c('SET_COUNTER','SS_PHASE',3),c('SET_TIMER','SS_EVENT',90)]))
 # Expiry precedes claims. A destroyed cache also closes the event without paying.
 steps.append(script('SS_EXPIRE',[eq('SS_PHASE',3),c('TIMER_EXPIRED','SS_EVENT')],[msg('EXPIRE','无人领取的补给已回收。下一批地点与奖励重新随机。'),c('SET_COUNTER','SS_PHASE',5)]))
 steps.append(script('SS_CACHE_DESTROYED',[eq('SS_PHASE',3),invert(exists('SS_DROP_MARKER'))],[msg('DESTROYED','补给仓已被摧毁，本轮结束。'),c('SET_COUNTER','SS_PHASE',5)]))
 # Rotate same-tick arbitration randomly so Player_1 is not always preferred.
 for priority in range(1,7):
  for offset in range(6):
   p=(priority-1+offset)%6+1
   for si,(_,wp) in enumerate(sites,1):
    cond=[eq('SS_PHASE',3),eq('SS_SITE',si),eq('SS_PRIORITY',priority),c('SKIRMISH_PLAYER_HAS_UNITS_IN_AREA',f'Player_{p}',f'SS_LOOT_AREA_{si}')]
    steps.append(script(f'SS_CLAIM_{priority}_{p}_{si}',cond,[c('SET_COUNTER','SS_WINNER',p),c('SET_COUNTER','SS_PHASE',4)]))
 rewards={1:dict(name='资金1500',cash=1500),2:dict(name='资金3000',cash=3000),3:dict(name='动员兵小队',unit='SovietAntiInfantryInfantry',count=4),4:dict(name='天狗机甲',unit='JapanAntiInfantryVehicle',count=1),5:dict(name='激流运输车',unit='AlliedAntiInfantryVehicle',count=1),6:dict(name='双刃直升机',unit='SovietAntiGroundAircraft',count=1)}
 for loot,reward in rewards.items():
  for p in range(1,7):
   locations=[(None,None)] if 'cash' in reward else list(enumerate(sites,1))
   for si,site in locations:
    cond=[eq('SS_PHASE',4),eq('SS_WINNER',p),eq('SS_LOOT',loot)]
    if si is not None:cond.append(eq('SS_SITE',si))
    actions=[c('PLAYER_GIVE_MONEY',f'Player_{p}',reward['cash'])] if 'cash' in reward else [c('CREATE_UNNAMED_ON_TEAM_AT_WAYPOINT',reward['unit'],team(p),site[1]) for _ in range(reward['count'])]
    actions = [c('NAMED_DELETE','SS_DROP_MARKER')] + actions
    actions += [msg(f'LOOT_{p}_{loot}',f'{p}号玩家领取了'+reward['name']+'。'),c('SET_COUNTER','SS_PHASE',5)]
    steps.append(script(f'SS_AWARD_{loot}_{p}_{si}',cond,actions))
 steps.append(script('SS_DELETE_CACHE',[eq('SS_PHASE',5),exists('SS_DROP_MARKER')],[c('NAMED_DELETE','SS_DROP_MARKER')]))
 steps.append(script('SS_END_EVENT',[eq('SS_PHASE',5)],[c('MAP_UNDO_REVEAL_PERMANENTLY_AT_WAYPOINT','SS_DROP_REVEAL'),c('SET_COUNTER','SS_PHASE',0),c('SET_RANDOM_MSEC_TIMER','SS_EVENT',90.,210.)]))
 # Hold a captured beacon continuously; captures reset the clock, neutralization cancels it.
 for gun in cfg['coastal_guns']:
  r=gun['region'];beacon=r+'_BEACON';done='SS_GUN_DONE_'+r;owner='SS_HOLD_OWNER_'+r;timer='SS_HOLD_'+r;uid='SS_COASTAL_GUN_'+r
  for p in range(1,7):
   steps.append(script(f'SS_HOLD_START_{r}_{p}',[flag(done,False),exists(beacon),owned(p,beacon),neq(owner,p)],[c('SET_COUNTER',owner,p),c('SET_TIMER',timer,gun['hold_seconds']),msg(f'HOLD_{r}_{p}',f'{p}号玩家启动'+labels[r]+'岸防挑战：连续控制120秒。')]))
  steps.append(script('SS_HOLD_RESET_'+r,[flag(done,False),neq(owner,0)]+[invert(owned(p,beacon)) for p in range(1,7)],[c('SET_COUNTER',owner,0),msg('HOLD_RESET_'+r,labels[r]+'控制中断，岸防挑战重新计时。')]))
  for p in range(1,7):
   cond=[flag(done,False),eq(owner,p),exists(beacon),owned(p,beacon),c('TIMER_EXPIRED',timer)]
   actions=[c('CREATE_NAMED_ON_TEAM_AT_WAYPOINT_WITH_ORIENTATION',uid,'BB_EuropeCoastalGun',team(p),'SS_GUN_'+r+'_PAD',float(gun['orientation'])),c('NAMED_FORCE_ATTACK_WAYPOINT',uid,'SS_GUN_'+r+'_AIM'),c('NAMED_FLASH',uid,15),c('SET_FLAG',done,True),msg(f'GUN_{r}_{p}',f'{p}号玩家完成挑战！'+labels[r]+'岸防炮已开始封锁指定海域。')]
   steps.append(script(f'SS_HOLD_WIN_{r}_{p}',cond,actions))
 # Only one short caption at a time, with a quiet gap; no persistent HUD panel.
 for key,number in list(messages.items()):
  steps.append(script('SS_NOTICE_'+key,[eq('SS_MESSAGE',number),c('TIMER_EXPIRED','SS_NOTICE_COOLDOWN')],[c('SHOW_MILITARY_CAPTION','MSN:STRAITSTORM12:'+key,4.),c('SET_COUNTER','SS_MESSAGE',0),c('SET_TIMER','SS_NOTICE_COOLDOWN',8)]))
 tree=read_tree(m,m.get('PlayerScriptsList'));assert len(tree['children'])==17 and all(not o.get('children') for o in tree['children'])
 tree['children'][0]['children']=steps;encoded=write_tree(m,tree);m.get('PlayerScriptsList')[2]=encoded[10:];assert write_tree(m,read_tree(m,m.get('PlayerScriptsList')))==encoded
 (ROOT/'event-tree.json').write_text(json.dumps(tree,ensure_ascii=False,indent=2))
 report=dict(version='1.2-random',script_count=len(steps),supply_sites=len(sites),first_wait_seconds=[90,180],later_wait_seconds=[90,210],warning_seconds=15,window_seconds=90,rewards=rewards,max_live_supply_markers=1,max_coastal_guns=3,hold_seconds=120,persistent_timer_panel=False,caption_seconds=4,caption_minimum_interval_seconds=8,randomness='Native synchronized RA3 random timer and counter actions')
 text='\r\n\r\n'.join(f'{k}\r\n"{v}"\r\nEND' for k,v in strings.items())+'\r\n'
 return report,text
