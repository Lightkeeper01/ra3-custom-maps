import numpy as np,json,pathlib
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from scipy.ndimage import gaussian_filter
D=pathlib.Path('outputs');data=np.load('work/terrain.npz');sc=json.load(open('work/scene.json'));h=data['height'][30:630,30:630];reg=data['regions'][30:630,30:630];rd=data['roadmask'][30:630,30:630];um=data['urbanmask'][30:630,30:630];pm=data['portmask'][30:630,30:630]
gy,gx=np.gradient(h);light=np.clip((-.55*gx+.6*gy+4)/np.sqrt(gx*gx+gy*gy+16),.25,1.3)
# Terrain-derived preview, north up. Palette is cartographic, not a claimed game capture.
sea=np.array([16,66,83.]);shallow=np.array([40,132,137.]);sand=np.array([179,163,115.]);grass=np.array([66,97,65.]);mount=np.array([137,135,110.])
c=np.zeros((*h.shape,3))
t=np.clip((h-110)/90,0,1)[...,None];c[:]=sea*(1-t)+shallow*t
mask=h>200;t=np.clip((h-202)/23,0,1)[...,None];lc=sand*(1-t)+grass*t
mt=np.clip((h-250)/110,0,1)[...,None];lc=lc*(1-mt)+mount*mt;c[mask]=lc[mask]
c[rd]=[126,123,105];c[um|pm]=[137,147,142];c[mask]*=light[mask,None]*.52+.55
c=np.clip(c,0,255).astype('uint8');im=Image.fromarray(c[::-1]).resize((1200,1200),Image.Resampling.LANCZOS)
d=ImageDraw.Draw(im,'RGBA');
# Coastline contour from sea crossing.
shore=(h>200)&(h<205);coast=np.zeros((600,600,4),np.uint8);coast[shore]=[201,215,168,145];coast=Image.fromarray(coast[::-1]).resize(im.size);im=Image.alpha_composite(im.convert('RGBA'),coast);d=ImageDraw.Draw(im,'RGBA')
def available_font(paths):
 for p in paths:
  if pathlib.Path(p).exists():return p
 raise FileNotFoundError('Install an appropriate font and update preview.py font search paths.')
font=available_font(['/System/Library/Fonts/Supplemental/Arial.ttf','C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'])
f=lambda n:ImageFont.truetype(font,n)
for o in sc['objects']:
 x,y=o['pos'][0]/5,1200-o['pos'][1]/5;t=o['type']
 if t=='OreNode':d.polygon([(x,y-5),(x+5,y),(x,y+5),(x-5,y)],fill='#e4c27a')
 elif t=='OilDerrick':d.rectangle((x-4,y-4,x+4,y+4),fill='#dddad0')
 elif 'Building_' in t or 'BUILDING_' in t:d.rectangle((x-3,y-3,x+3,y+3),fill=(220,215,192,190))
colors=['#e44a40','#67c4b9','#edb45e','#b59cdb','#76acd9','#88b56a']
for i,(x,y) in enumerate(sc['starts']):
 x*=2;y=1200-y*2;d.ellipse((x-22,y-22,x+22,y+22),fill=(10,25,31,245),outline=colors[i],width=3);d.text((x,y-1),str(i+1),font=f(28),anchor='mm',fill='white')
# Vanilla-compatible 24-bit 512px TGA.
name='Strait_Reunification_6P';mini=im.convert('RGB').resize((512,512),Image.Resampling.LANCZOS);mini.save(D/name/(name+'_art.tga'));mini.save(D/name/(name+'_pic.tga'));im.convert('RGB').save(D/'海峡风云_地形小地图.png')
# Presentation sheet rendered from exact playable area.
W,H=1900,1510;sheet=Image.new('RGB',(W,H),'#101e26');sheet.paste(im.convert('RGB'),(48,235));d=ImageDraw.Draw(sheet)
cf=available_font(['/System/Library/AssetsV2/com_apple_MobileAsset_Font7/3419f2a427639ad8c8e139149a287865a90fa17e.asset/AssetData/PingFang.ttc','/System/Library/Fonts/PingFang.ttc','C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'])
cn=lambda n:ImageFont.truetype(cf,n,index=0)
d.text((50,43),'STRAIT / 06',font=f(25),fill='#bdb28c');d.text((48,86),'海峡风云：收复行动',font=cn(64),fill='#f1eadb');d.text((52,176),'红色警戒 3 原版  ·  六方架空战场  ·  地形数据预览',font=cn(23),fill='#9eafb7')
d.line((1290,237,1290,1436),fill='#3a4950',width=1)
d.text((1340,244),'六个战场席位',font=cn(35),fill='#f1eadb')
rows=[('01','中国大陆','苏联科技树','福建沿海 · 海陆主基地'),('02','台湾','盟军科技树','本岛西部 · 山海纵深'),('03','日本','帝国科技树','东北外围岛屿'),('04','俄罗斯','苏联科技树','北部外围基地'),('05','美国','盟军科技树','东部海上支援基地'),('06','澳大利亚','盟军科技树','南部外围基地')]
for i,(n,title,faction,where) in enumerate(rows):
 y=320+i*136;d.text((1340,y),n,font=f(26),fill=colors[i]);d.text((1400,y-7),title,font=cn(30),fill='#e3e7e7');d.text((1400,y+35),faction,font=cn(21),fill='#b7c2c5');d.text((1400,y+65),where,font=cn(20),fill='#809aa7')
d.line((1340,1155,1835,1155),fill='#3a4950',width=1)
d.text((1340,1190),'600 × 600 / 30 矿点 / 6 油井',font=cn(23),fill='#d8c79e')
d.text((1340,1240),'推荐：1、4 同盟；2、3、5、6 同盟',font=cn(20),fill='#a6b5bb')
d.text((1340,1280),'自由遭遇战需手动指定阵营、位置和队伍',font=cn(19),fill='#a6b5bb')
d.text((1340,1340),'外围地理为玩法压缩；参战安排属虚构。',font=cn(18),fill='#7e949e')
d.text((50,1460),'构图与地形来自交付 .map 同一份数据。此图为地形预览，非游戏实机截图。',font=cn(19),fill='#859da8')
sheet.save(D/'海峡风云_战场总览.png')
Image.fromarray(np.rint(data['height']/.0390625).astype('uint16')).save(D/'海峡风云_16位高度图.png')
print('Preview and minimaps saved')
