import bpy,numpy as np,json,math,random,pathlib
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parent.parent;OUT=ROOT/'outputs';data=np.load(ROOT/'work/terrain.npz');sc=json.load(open(ROOT/'work/scene.json'));random.seed(921)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
 if c.name!='Collection':bpy.data.collections.remove(c)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=True
scene.render.resolution_x=2400;scene.render.resolution_y=1800;scene.render.resolution_percentage=100
scene.world.color=(.18,.23,.3);scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.24,.32,.43,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
scene.view_settings.view_transform='AgX'
def mat(n,col,rough=.65,metal=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*col,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
concrete=mat('Port concrete',(.36,.39,.36));dark=mat('Graphite metal',(.085,.12,.14),.42,.6);ivory=mat('Warm concrete',(.62,.60,.49));glass=mat('Blue glazing',(.12,.22,.26),.22,.4);roof=mat('Roofs',(.25,.28,.29));trunk=mat('Tree trunks',(.17,.12,.07));leafm=[mat('Canopy '+str(i),c) for i,c in enumerate([(.09,.19,.095),(.15,.25,.12),(.20,.29,.145),(.10,.23,.14)])];rockmat=mat('Rocks',(.36,.37,.32));containers=[mat('Container '+str(i),c) for i,c in enumerate([(.48,.16,.10),(.20,.35,.35),(.64,.49,.25),(.26,.31,.41)])]
# Build exact heightfield, playable square only. Render height is vertically exaggerated 2x for legibility.
h=data['height'][30:630,30:630];N=600;verts=[((x-300)*.1,(y-300)*.1,(float(h[y,x])-200)*.02) for y in range(N) for x in range(N)];faces=[(y*N+x,y*N+x+1,(y+1)*N+x+1,(y+1)*N+x) for y in range(N-1) for x in range(N-1)]
mesh=bpy.data.meshes.new('Native map heightfield');mesh.from_pydata(verts,[],faces);mesh.update();terrain=bpy.data.objects.new('Terrain — exact .map data, vertical 2x',mesh);scene.collection.objects.link(terrain)
# Use vertex colors classified from actual native terrain assignments.
col=mesh.color_attributes.new(name='TerrainColor',type='FLOAT_COLOR',domain='POINT');types=data['types'][30:630,30:630];colors=np.zeros((N,N,4),np.float32);colors[:]=[.17,.26,.13,1]
colors[types==4]=[.22,.32,.16,1];colors[types==3]=[.23,.30,.17,1];colors[types==28]=[.59,.51,.31,1];colors[types==34]=[.27,.37,.27,1];colors[types==5]=[.33,.34,.28,1];colors[types==14]=[.37,.33,.24,1];colors[types==38]=[.42,.45,.41,1]
col.data.foreach_set('color',colors.reshape(-1));ground=mat('Terrain PBR',(.2,.3,.2));nt=ground.node_tree;p=nt.nodes.get('Principled BSDF');vc=nt.nodes.new('ShaderNodeVertexColor');vc.layer_name='TerrainColor';nt.links.new(vc.outputs['Color'],p.inputs['Base Color']);noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=24;noise.inputs['Detail'].default_value=4;bum=nt.nodes.new('ShaderNodeBump');bum.inputs['Strength'].default_value=.25;bum.inputs['Distance'].default_value=.045;nt.links.new(noise.outputs['Fac'],bum.inputs['Height']);nt.links.new(bum.outputs[0],p.inputs['Normal']);terrain.data.materials.append(ground)
for poly in mesh.polygons:poly.use_smooth=True
# Reflective ocean with multi-scale micro-wave normals.
water=mat('Strait ocean',(.017,.125,.16),.22,.32);nt=water.node_tree;p=nt.nodes.get('Principled BSDF');p.inputs['IOR'].default_value=1.333;p.inputs['Transmission Weight'].default_value=.12
nz=nt.nodes.new('ShaderNodeTexNoise');nz.inputs['Scale'].default_value=6;nz.inputs['Detail'].default_value=4;nz.inputs['Roughness'].default_value=.7
bn=nt.nodes.new('ShaderNodeBump');bn.inputs['Strength'].default_value=.38;bn.inputs['Distance'].default_value=.065;nt.links.new(nz.outputs['Fac'],bn.inputs['Height']);nt.links.new(bn.outputs[0],p.inputs['Normal'])
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.015));o=bpy.context.object;o.name='Ocean surface';o.data.materials.append(water)
# Mesh instances of architectural proxies, aligned with native object placements.
unitmeshes={}
def cubemesh():
 if 'cube' not in unitmeshes:
  bpy.ops.mesh.primitive_cube_add();o=bpy.context.object;unitmeshes['cube']=o.data;bpy.data.objects.remove(o,do_unlink=True)
 return unitmeshes['cube']
def cube(n,loc,scale,ma,angle=0):
 o=bpy.data.objects.new(n,cubemesh());scene.collection.objects.link(o);o.location=loc;o.scale=scale;o.rotation_euler[2]=angle;o.data=o.data.copy();o.data.materials.clear();o.data.materials.append(ma);return o
def height(x,y):return (float(h[max(0,min(599,int(y))),max(0,min(599,int(x)))])-200)*.02
# Lower-poly merged evergreen crowns preserve dense foliage without heavyweight assets.
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1);proto=bpy.context.object;leafmesh=proto.data;bpy.data.objects.remove(proto,do_unlink=True)
def crown(loc,scale,ma,name):
 o=bpy.data.objects.new(name,leafmesh);scene.collection.objects.link(o);o.location=loc;o.scale=scale;o.data=o.data.copy();o.data.materials.clear();o.data.materials.append(ma)
for ob in sc['objects']:
 t=ob['type'];x,y=ob['pos'][0]/10,ob['pos'][1]/10;xx,yy=(x-300)*.1,(y-300)*.1;z=height(x,y);angle=ob['pos'][3]
 if 'Tree' in t or 'TREE' in t:
  s=random.uniform(.07,.14);cube('Trunk',(xx,yy,z+s),(.015,.015,s),trunk)
  for k in range(3):crown((xx+random.uniform(-.055,.055),yy+random.uniform(-.055,.055),z+.15+k*.06),(s,s,s*1.3),random.choice(leafm),'Forest canopy')
 elif 'Shrub' in t or 'BUSH' in t:crown((xx,yy,z+.055),(.085,.07,.075),random.choice(leafm),'Coastal shrub')
 elif 'ROCK' in t:crown((xx,yy,z+.06),(.12,.085,.1),rockmat,'Rock outcrop')
 elif 'Building_' in t or 'BUILDING_' in t:
  v=sum(t.encode())%5;w=.22 if v<3 else .28;de=.21;hh=.18+v*.15
  cube('City block '+t,(xx,yy,z+hh),(w,de,hh),ivory,0);cube('Rooftop',(xx,yy,z+hh*2+.02),(w*1.03,de*1.03,.025),roof)
  for k in range(1,3+v):
   zz=z+k*(hh*2/(3+v));cube('Glazing strip',(xx,yy-de-.005,zz),(w*.92,.009,.018),glass);cube('Glazing strip',(xx+w+.005,yy,zz),(.009,de*.92,.018),glass)
  cube('Roof equipment',(xx+.08,yy,z+2*hh+.065),(.07,.06,.04),dark)
 elif 'CONTAINER' in t:
  ma=containers[sum(t.encode())%4];cube('Container',(xx,yy,z+.07),(.065,.15,.07),ma)
  for k in range(5):cube('Container ribs',(xx+.066,yy-.12+k*.06,z+.07),(.004,.005,.065),dark)
 elif 'crane' in t:
  for dx in [-.10,.10]:
   for dy in [-.13,.13]:cube('Crane leg',(xx+dx,yy+dy,z+.3),(.018,.018,.3),dark)
  cube('Crane gantry',(xx,yy,z+.59),(.16,.22,.025),ivory);cube('Crane boom',(xx+.17,yy,z+.69),(.43,.023,.027),ivory);cube('Crane cable',(xx+.53,yy,z+.46),(.005,.005,.22),dark)
 elif t=='OreNode':
  cube('Ore processing pad',(xx,yy,z+.02),(.22,.18,.025),concrete);cube('Ore processing building',(xx,yy,z+.10),(.11,.11,.09),roof);crown((xx+.18,yy,z+.055),(.16,.15,.10),containers[2],'Ore stockpile')
 elif t=='OilDerrick':
  for dx in [-.075,.075]:cube('Oil tower leg',(xx+dx,yy,z+.16),(.015,.03,.16),dark)
  cube('Oil tower beam',(xx,yy,z+.31),(.14,.025,.025),ivory)
 elif 'Lighthouse' in t:
  cube('Lighthouse',(xx,yy,z+.22),(.07,.07,.22),ivory);cube('Beacon',(xx,yy,z+.46),(.1,.1,.035),containers[0])
# Harbor platforms read crisply above water.
for x,y,sx,sy in sc['ports']:
 cube('Concrete quay',((x-300)*.1,(y-300)*.1,.27),(sx*.1,sy*.1,.03),concrete)
# Start-zone rings are presentation annotations and do not pretend to be installed military units.
ringm=[mat('Seat '+str(i),c,.35,.3) for i,c in enumerate([(.65,.07,.04),(.1,.5,.43),(.78,.44,.08),(.4,.24,.65),(.12,.39,.65),(.3,.55,.16)])]
for i,(x,y) in enumerate(sc['starts']):
 xx,yy=(x-300)*.1,(y-300)*.1;z=height(x,y)+.035;bpy.ops.mesh.primitive_torus_add(major_radius=1.25,minor_radius=.025,major_segments=80,minor_segments=6,location=(xx,yy,z));o=bpy.context.object;o.name='Seat '+str(i+1);o.data.materials.append(ringm[i])
# Lighting and camera.
bpy.ops.object.light_add(type='SUN',location=(0,0,20));sun=bpy.context.object;sun.rotation_euler=(math.radians(25),math.radians(-25),math.radians(-28));sun.data.energy=2.6;sun.data.angle=math.radians(12);sun.data.color=(1,.88,.67)
bpy.ops.object.camera_add(location=(14,-46,62));cam=bpy.context.object;scene.camera=cam;cam.rotation_euler=(Vector((0,2,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=86;cam.data.lens=45;cam.data.clip_end=500
scene.render.image_settings.file_format='PNG';scene.render.filepath=str(OUT/'海峡风云_3D地形预览.png')
scene['NOTICE']='Terrain preview derived from .map; proxy art, not game screenshot. Vertical exaggeration 2x.'
# Camera-space production label is part of the editable scene, not a retouched image.
ink=bpy.data.materials.new('Preview label ink');ink.use_nodes=True;ns=ink.node_tree.nodes;ns.clear();out=ns.new('ShaderNodeOutputMaterial');em=ns.new('ShaderNodeEmission');em.inputs[0].default_value=(.89,.92,.87,1);ink.node_tree.links.new(em.outputs[0],out.inputs[0])
labelobjs=[]
for text,size,y in [('STRAIT / 06    —    TERRAIN STUDY',1.0,.457),('MAP DATA / 2X HEIGHT / PROXY SCENERY / NOT A GAME SCREENSHOT',.49,.434)]:
 curve=bpy.data.curves.new('Preview caption','FONT');curve.body=text;curve.size=size;ob=bpy.data.objects.new('Preview caption',curve);scene.collection.objects.link(ob);ob.parent=cam;ob.data.materials.append(ink);labelobjs.append((ob,size,y))
def update_labels():
 span=cam.data.ortho_scale;vs=span*scene.render.resolution_y/scene.render.resolution_x
 for ob,size,y in labelobjs:ob.location=(-span*.465,vs*y,-5);ob.data.size=size*span/86
update_labels()

bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'海峡风云_地形预览.blend'));bpy.ops.render.render(write_still=True)
# Closer coastline view for terrain/port QA.
cam.location=(0,-19,26);cam.rotation_euler=(Vector((1.5,5,.5))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=31;scene.render.resolution_x=2200;scene.render.resolution_y=1600;scene.render.filepath=str(OUT/'海峡风云_海岸细节预览.png');update_labels();bpy.ops.render.render(write_still=True)
