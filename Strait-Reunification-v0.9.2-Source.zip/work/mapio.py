import struct, pathlib, json
P=lambda f,*v:struct.pack('<'+f,*v)
class R:
 def __init__(self,b):self.b=b;self.p=0
 def n(self,n): v=self.b[self.p:self.p+n]; assert len(v)==n;self.p+=n;return v
 def u(self,f):return struct.unpack('<'+f,self.n(struct.calcsize('<'+f)))[0]
 def s(self,wide=False):return self.n(self.u('H')*(2 if wide else 1)).decode('utf-16le' if wide else 'ascii')
 def var(self):
  n=s=0
  while True:
   a=self.u('B');n|=(a&127)<<s;s+=7
   if a<128:return n

def decompress(b):
 if b[:4]==b'CkMp':return b
 assert b[:4]==b'EAR\0'
 size=struct.unpack_from('<I',b,4)[0];r=R(b[8:]);h=r.u('B');assert r.u('B')==251
 n=4 if h&128 else 3
 if h&1:r.n(n)
 assert int.from_bytes(r.n(n),'big')==size
 out=bytearray()
 while True:
  a=r.u('B');num=dist=0
  if a<128:
   b=r.u('B');lit=a&3;num=((a&28)>>2)+3;dist=((a&96)<<3)+b+1
  elif a<192:
   b,c=r.n(2);lit=b>>6;num=(a&63)+4;dist=((b&63)<<8)+c+1
  elif a<224:
   b,c,d=r.n(3);lit=a&3;num=((a&12)<<6)+d+5;dist=((a&16)<<12)+(b<<8)+c+1
  elif a<252:lit=((a&31)+1)*4
  else:lit=a&3
  out+=r.n(lit)
  for _ in range(num):out.append(out[-dist])
  if a>=252:break
 assert len(out)==size
 return bytes(out)
class Map:
 def __init__(self,path):
  b=decompress(pathlib.Path(path).read_bytes());r=R(b);assert r.n(4)==b'CkMp';self.names={}
  for _ in range(r.u('I')):
   s=r.n(r.var()).decode('utf-8');i=r.u('I');self.names[i]=s
  self.rev={s:i for i,s in self.names.items()};self.chunks=self.chunks_read(r.n(len(b)-r.p))
 def chunks_read(self,b):
  r=R(b);out=[]
  while r.p<len(b):
   i=r.u('I');v=r.u('H');n=r.u('I');out.append([self.names[i],v,r.n(n)])
  return out
 def get(self,n):return next(c for c in self.chunks if c[0]==n)
 def key(self,s):
  if s not in self.rev:i=len(self.rev)+1;self.rev[s]=i;self.names[i]=s
  return self.rev[s]
 def chunk(self,c):return P('IHI',self.key(c[0]),c[1],len(c[2]))+c[2]
 def props(self,b):
  r=b if isinstance(b,R) else R(b);d={}
  for _ in range(r.u('H')):
   t=r.u('B');s=self.names[int.from_bytes(r.n(3),'little')]
   v=r.u({0:'B',1:'i',2:'f'}[t]) if t<3 else r.s(t==4)
   d[s]=(t,v)
  return d
 def props_write(self,d):
  b=P('H',len(d))
  for s,(t,v) in d.items():b+=P('B',t)+self.key(s).to_bytes(3,'little')+(P({0:'B',1:'i',2:'f'}[t],v) if t<3 else string(v,t==4))
  return b
 def objects(self):
  out=[]
  for n,v,b in self.chunks_read(self.get('ObjectsList')[2]):
   r=R(b);pos=struct.unpack('<4fI',r.n(20));typ=r.s();d=self.props(r);assert r.p==len(b);out.append(dict(ver=v,pos=pos,type=typ,props=d))
  return out
 def obj_write(self,o):return self.chunk(['Object',o['ver'],P('4fI',*o['pos'])+string(o['type'])+self.props_write(o['props'])])
 def write(self,path):
  body=b''.join(self.chunk(c) for c in self.chunks);b=b'CkMp'+P('I',len(self.names))
  for i in sorted(self.names,reverse=True):
   s=self.names[i].encode();n=len(s);v=b''
   while n>=128:v+=bytes([(n&127)|128]);n>>=7
   b+=v+bytes([n])+s+P('I',i)
  pathlib.Path(path).write_bytes(b+body)
def string(s,wide=False):
 b=s.encode('utf-16le' if wide else 'ascii');return P('H',len(b)//(2 if wide else 1))+b
if __name__=='__main__':
 import sys,collections
 m=Map(sys.argv[1]);print([(n,v,len(b)) for n,v,b in m.chunks]);print('WORLD',m.props(m.get('WorldInfo')[2]));print('HEIGHT',m.get('HeightMapData')[2][:40].hex());print('WATER',m.get('GlobalWaterSettings')[2].hex());obs=m.objects();print(collections.Counter(o['type'] for o in obs));print('WAYPOINTS',[o for o in obs if o['type']=='Waypoint']);pathlib.Path('work/objects.json').write_text(json.dumps(obs,ensure_ascii=False,indent=2))
