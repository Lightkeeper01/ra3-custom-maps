"""RA3 ore placement lattice, calibrated from EA's same-size Carville map.

The 30-unit building grid is rotated 45 degrees relative to terrain cells.
Ore footprints span 120 x 90 units, so alternate orientations have different
half-cell center phases. This calibration is only for the inherited map extent.
"""
import math
import statistics

STEP = 30.0
DIAGONALS = tuple(math.pi / 4 + k * math.pi / 2 for k in range(4))


def uv(x, y):
    return ((x + y) / math.sqrt(2), (y - x) / math.sqrt(2))


def calibrate(reference):
    groups = [[], []]
    for obj in reference.objects():
        if obj['type'] != 'OreNode':
            continue
        x, y, _, angle, _ = obj['pos']
        k = round((angle - math.pi / 4) / (math.pi / 2))
        assert abs(angle - (math.pi / 4 + k * math.pi / 2)) < 1e-5
        groups[k % 2].append(uv(x, y))
    phases = []
    for rows in groups:
        anchor = rows[0]
        phase = tuple(anchor[j] + statistics.median(
            (row[j] - anchor[j] + STEP / 2) % STEP - STEP / 2
            for row in rows) for j in range(2))
        assert all(abs((row[j] - phase[j] + 15) % 30 - 15) < .002
                   for row in rows for j in range(2))
        phases.append(phase)
    return phases


def snap(x, y, angle, phases):
    """Input/output positions are in terrain cells, angles in radians."""
    k = round((angle - math.pi / 4) / (math.pi / 2))
    angle = math.atan2(math.sin(DIAGONALS[k % 4]), math.cos(DIAGONALS[k % 4]))
    u, v = uv(x * 10, y * 10)
    pu, pv = phases[k % 2]
    u = pu + round((u - pu) / STEP) * STEP
    v = pv + round((v - pv) / STEP) * STEP
    return ((u - v) / math.sqrt(2) / 10,
            (u + v) / math.sqrt(2) / 10, angle)
