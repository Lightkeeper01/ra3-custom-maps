# Strait Reunification [6P] - source bundle

The original six-player fictional strait map: 30 ore nodes, six oil derricks and standard vanilla factions.

This is the corresponding map-generation source archive. Extract it into an empty working directory. All `work/...` paths are relative to that directory; run from the archive root. Use Python 3.11 with numpy, scipy and Pillow installed. Original asset and format-reference licenses are included.

Build with `python3 work/build_map.py`, then `python3 work/validate_map.py` and `python3 work/preview.py` from the archive root.

The archive retains original project paths and developer documents, some of which are in Chinese. The public player ZIP has an English installation guide. Do not run a generator inside a directory containing work you want to preserve.

The author reported a playable match. This is not a certification of every faction, AI setting or multiplayer configuration.
