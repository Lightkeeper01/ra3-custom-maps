# Black Tide - Salvage Wars [6P]

A compact six-player island arena with an opening raid squad, rotating relay contracts, random salvage, mixed-faction reinforcements and coastal artillery.

## Requirements

Command & Conquer: Red Alert 3, vanilla PC version 1.12. A separate copy of the game is required. These packages do not contain the game. Maps are not intended for Uprising, Red Alert 2 or other C&C titles. No additional mod is required.

## Install

1. Extract the entire ZIP.
2. Either run `Install-Map.cmd`, or use the manual steps below.
3. Restart RA3 and start a new skirmish. Select **Black Tide - Salvage Wars [6P]**.

Manual installation: press Win+R, enter `%APPDATA%\Red Alert 3\Maps` and press Enter. Create the Maps folder if necessary. Copy the complete `Black_Tide_6P` directory into it. Inside that directory must be one same-name `.map`, two `.tga` previews and `map.str`; avoid a second nested directory. Install under the Windows account that runs the game. The installer backs up an existing same-name map; other map folders are preserved.

If the installer does not run or appears stuck, use manual copying. You do not need to change system-wide script execution policy. To uninstall, remove only the `Black_Tide_6P` folder from Maps.

## Play

Start with 2 Riptides and 1 Engineer. The first salvage arrives in 60-75 seconds. Capture the flashing Observation Post with an Engineer and hold it for 45 seconds to earn $1500 plus reinforcements. Targets rotate between AIRFIELD, SHIPYARD and ARSENAL. A winner has a 120-second contract cooldown. At 6 minutes, the reward becomes $2200 with stronger squads. The first completed contract on each island also grants a coastal gun. All custom notifications use English ASCII text.

All maps retain the standard skirmish elimination win condition. Choose teams, factions and AI difficulty in the lobby. Six starting positions do not add six new playable national factions. Country labels in the original strait theme are fictional scenario roles. Use identical map versions on every machine for multiplayer.

## Validation status

Experimental release. Geometry and 19 event-model scenarios passed; a source archive rebuild was byte-identical. In-game rendering, balance and multiplayer behavior still need playtesting.

Automated script simulation is not the actual RA3 engine. Please report the map version, game version, player slot, faction, AI/team setup, exact steps and approximate match time with any bug report.

## Credits and licensing

Made available by Lightkeeper01. Uses native RA3 objects and format references from EA's CnC_Modding_Support and OpenSAGE. Preserve the accompanying license notices. Source bundles are supplied separately in the same GitHub repository. This is an unofficial community map project, not endorsed by Electronic Arts.
