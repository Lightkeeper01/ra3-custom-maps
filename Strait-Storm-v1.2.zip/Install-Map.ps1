$ErrorActionPreference = 'Stop'
$mapName = 'Strait_Storm_6P'
$source = Join-Path $PSScriptRoot $mapName
$destination = Join-Path $env:APPDATA ('Red Alert 3\Maps\'+$mapName)
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Map-Checksums.json') -Raw | ConvertFrom-Json
foreach ($e in $manifest.PSObject.Properties) {
 if ((Get-FileHash -LiteralPath (Join-Path $source $e.Name) -Algorithm SHA256).Hash -ne $e.Value) { throw ('Invalid download: '+$e.Name) }
}
if (Test-Path -LiteralPath $destination) {
 $backupRoot=Join-Path $env:APPDATA 'Red Alert 3\CodexMapBackups'
 New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
 $backup=Join-Path $backupRoot ($mapName+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
 Copy-Item -LiteralPath $destination -Destination $backup -Recurse
 Write-Output ('Previous version backed up: '+$backup)
}
New-Item -ItemType Directory -Path $destination -Force | Out-Null
Get-ChildItem -LiteralPath $source -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $destination -Force }
foreach ($e in $manifest.PSObject.Properties) {
 if ((Get-FileHash -LiteralPath (Join-Path $destination $e.Name) -Algorithm SHA256).Hash -ne $e.Value) { throw ('Installed checksum mismatch: '+$e.Name) }
}
Write-Output ('Installed: '+$destination)
Write-Output 'Restart Red Alert 3. Select Strait Storm - Wild Supplies [6P] in the skirmish map list.'
