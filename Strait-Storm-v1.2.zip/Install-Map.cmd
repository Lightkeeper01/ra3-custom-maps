@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Map.ps1"
if errorlevel 1 (echo Installation failed. See README for manual installation.) else (echo Installation complete.)
pause
